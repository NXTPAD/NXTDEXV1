// NXT DEX — developer-only password gate (Cloudflare Pages Function)
// Runs on Cloudflare's servers BEFORE any file is served, so nothing
// (HTML, JS, contracts, images) leaks to people without the password.
//
// Setup: Cloudflare dashboard → Workers & Pages → your NXT DEX project →
// Settings → Variables and Secrets → add a SECRET named DEV_PASSWORD.
// To remove the gate at public launch, delete this file (or the whole
// /functions folder) and redeploy.

const COOKIE = "nxt_dev";
const LOGIN_PATH = "/__dev-login";
const LOGOUT_PATH = "/__dev-logout";
const MAX_AGE = 60 * 60 * 24 * 30; // stay signed in 30 days

async function sign(secret) {
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode("nxt-dex-dev-v1"));
  return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, "0")).join("");
}

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function getCookie(request, name) {
  const header = request.headers.get("Cookie") || "";
  const match = header.match(new RegExp("(?:^|;\\s*)" + name + "=([^;]+)"));
  return match ? match[1] : "";
}

function safeNext(value) {
  return value && value.startsWith("/") && !value.startsWith("//") ? value : "/";
}

function loginPage(next, error) {
  const html = `<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#07090f">
<title>NXT DEX — Developer access</title>
<style>
*{box-sizing:border-box;margin:0}
body{min-height:100vh;display:grid;place-items:center;background:radial-gradient(600px 400px at 30% 0%,#123b6b55,transparent),#07090f;color:#f1f7ff;font-family:system-ui,-apple-system,sans-serif;padding:16px}
.card{width:100%;max-width:380px;background:#0e131d;border:1px solid rgba(160,210,255,.12);border-radius:22px;padding:32px 26px;box-shadow:0 20px 60px #0008}
h1{font-size:22px;margin-bottom:6px}h1 span{color:#8fd3ff}
p{color:#8392a8;font-size:14px;line-height:1.5;margin-bottom:22px}
input{width:100%;padding:14px 16px;border-radius:14px;border:1px solid rgba(160,210,255,.15);background:#07090f;color:#f1f7ff;font-size:15px;outline:0}
input:focus{border-color:#4fb0ff}
button{width:100%;margin-top:12px;padding:14px;border:0;border-radius:14px;background:linear-gradient(135deg,#c4e8ff,#4fb0ff);color:#051422;font-weight:800;font-size:15px;cursor:pointer}
.err{color:#ff7a8a;font-size:13px;margin-top:10px}
</style></head><body>
<form class="card" method="POST" action="${LOGIN_PATH}">
  <h1>NXT <span>DEX</span></h1>
  <p>This build is in development. Enter the developer password to continue.</p>
  <input type="hidden" name="next" value="${next.replace(/"/g, "&quot;")}">
  <input type="password" name="password" placeholder="Developer password" autocomplete="current-password" autofocus required>
  <button type="submit">Enter</button>
  ${error ? `<div class="err">${error}</div>` : ""}
</form></body></html>`;
  return new Response(html, {
    status: 401,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Robots-Tag": "noindex, nofollow",
    },
  });
}

export async function onRequest(context) {
  const { request, env, next } = context;
  const url = new URL(request.url);
  const password = env.DEV_PASSWORD;

  // Fail closed: if the secret isn't set, nobody gets in.
  if (!password) {
    return new Response("Developer password not configured (set DEV_PASSWORD).", { status: 503 });
  }

  const token = await sign(password);

  if (url.pathname === LOGOUT_PATH) {
    return new Response(null, {
      status: 302,
      headers: { Location: "/", "Set-Cookie": `${COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax` },
    });
  }

  if (url.pathname === LOGIN_PATH && request.method === "POST") {
    const form = await request.formData();
    const attempt = String(form.get("password") || "");
    const dest = safeNext(String(form.get("next") || "/"));
    if (safeEqual(await sign(attempt), token)) {
      return new Response(null, {
        status: 302,
        headers: {
          Location: dest,
          "Set-Cookie": `${COOKIE}=${token}; Path=/; Max-Age=${MAX_AGE}; HttpOnly; Secure; SameSite=Lax`,
        },
      });
    }
    await new Promise(r => setTimeout(r, 800)); // slow down guessing
    return loginPage(dest, "Wrong password.");
  }

  if (safeEqual(getCookie(request, COOKIE), token)) {
    const res = await next();
    const out = new Response(res.body, res);
    out.headers.set("X-Robots-Tag", "noindex, nofollow");
    out.headers.set("Cache-Control", "private, no-store");
    return out;
  }

  return loginPage(safeNext(url.pathname + url.search), "");
}
