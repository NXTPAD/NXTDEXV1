/* NXT DEX — multichain swap & bridge front-end (LI.FI routing · no NXT DEX fee · NXT holders only) */
(() => {
"use strict";
const C = window.NXT_CONFIG;
const API = "https://li.quest/v1";
const SOL_ID = 1151111081099710;
const EVM_NATIVE = "0x0000000000000000000000000000000000000000";
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
/* ---------- logos ----------
   Order tried for every coin: bundled logo (known tokens, matched by contract
   address, never by symbol) → logo from the routing API → public logo CDN →
   generated badge (only if a token has no logo anywhere). */
const LOGO_DIR = "assets/logos/";
const NATIVE_LOGO = { 1: "eth", 8453: "eth", 42161: "eth", 10: "eth", 59144: "eth", 324: "eth", 534352: "eth", 81457: "eth", 7777777: "eth", 56: "bnb", 137: "pol", 43114: "avax", 1151111081099710: "sol" };
const CHAIN_LOGO = { 1: "eth", 8453: "chain-base", 42161: "chain-arbitrum", 10: "chain-optimism", 137: "pol", 56: "bnb", 43114: "avax", 1151111081099710: "sol" };
const TOKEN_LOGO = {
  usdc: ["1:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", "8453:0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", "42161:0xaf88d065e77c8cc2239327c5edb3a432268e5831", "10:0x0b2c639c533813f4aa9d7837caf62653d097ff85", "137:0x3c499c542cef5e3811e1192ce70d8cc03d5c3359", "56:0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d", "43114:0xb97ef9ef8734c71904d8002f8b6bc66dd9c48a6e", "1151111081099710:EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"],
  usdt: ["1:0xdac17f958d2ee523a2206206994597c13d831ec7", "42161:0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9", "56:0x55d398326f99059ff775485246999027b3197955", "137:0xc2132d05d31c914a87c6611c10748aeb04b58e8f", "1151111081099710:Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"],
  weth: ["1:0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2", "8453:0x4200000000000000000000000000000000000006", "10:0x4200000000000000000000000000000000000006", "42161:0x82af49447d8a07e3bd95bd0d56f35241523fbab1"],
  wbtc: ["1:0x2260fac5e5542a773aa44fbcfedf7c193bc2c599"],
  dai: ["1:0x6b175474e89094c44da98b954eedeac495271d0f"],
};
const TOKEN_LOGO_BY_KEY = Object.fromEntries(Object.entries(TOKEN_LOGO).flatMap(([f, keys]) => keys.map((k) => [k.toLowerCase(), f])));
const nxtLogo = () => (window.NXT_CONFIG && window.NXT_CONFIG.NXT_LOGO) || LOGO_DIR + "nxt.svg";
function tokenLogos(t, chainId) {
  if (!t) return [];
  const cid = Number(chainId ?? t.chainId), addr = String(t.address || "").toLowerCase(), out = [];
  const nxt = (window.NXT_CONFIG?.NXT_TOKENS || []).some((n) => Number(n.chainId) === cid && String(n.address).toLowerCase() === addr);
  if (nxt) out.push(nxtLogo());
  if (isNative(t) && NATIVE_LOGO[cid]) out.push(LOGO_DIR + NATIVE_LOGO[cid] + ".png");
  const f = TOKEN_LOGO_BY_KEY[cid + ":" + addr]; if (f) out.push(LOGO_DIR + f + ".png");
  if (t.logoURI) out.push(t.logoURI);
  if (addr && !isNative(t) && cid !== SOL_ID) out.push(`https://assets.smold.app/api/token/${cid}/${t.address}/logo-128.png`);
  return out;
}
function chainLogos(c) { if (!c) return []; const out = []; if (CHAIN_LOGO[c.id]) out.push(LOGO_DIR + CHAIN_LOGO[c.id] + ".png"); if (c.logoURI) out.push(c.logoURI); out.push(`https://assets.smold.app/api/chain/${c.id}/logo-128.png`); return out; }
function badge(label) {
  const t = String(label || "?").replace(/[^A-Za-z0-9]/g, "").slice(0, 4).toUpperCase() || "?";
  let h = 0; for (const ch of t) h = (h * 31 + ch.charCodeAt(0)) % 360;
  return "data:image/svg+xml;utf8," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${h},70%,62%)"/><stop offset="1" stop-color="hsl(${(h + 50) % 360},70%,40%)"/></linearGradient></defs><circle cx="20" cy="20" r="20" fill="url(#g)"/><text x="20" y="${t.length > 3 ? 24 : 25}" font-size="${t.length > 3 ? 10 : t.length > 2 ? 12 : 15}" font-weight="800" text-anchor="middle" fill="#fff" font-family="system-ui,sans-serif">${t}</text></svg>`);
}
window.nxtImgErr = (el) => {
  const alts = JSON.parse(el.dataset.alt || "[]");
  if (alts.length) { el.dataset.alt = JSON.stringify(alts.slice(1)); el.src = alts[0]; }
  else { el.onerror = null; el.src = badge(el.dataset.label); }
};
function img(srcs, cls = "ico", label = "") {
  const list = (Array.isArray(srcs) ? srcs : [srcs]).filter(Boolean);
  const first = list[0] || badge(label);
  return `<img class="${cls}" src="${esc(first)}" data-alt="${esc(JSON.stringify(list.slice(1)))}" data-label="${esc(label)}" onerror="nxtImgErr(this)" alt="" loading="lazy">`;
}
const tokImg = (t, chainId, cls = "ico") => img(tokenLogos(t, chainId), cls, t?.symbol);
const chainImg = (c, cls = "ico") => img(chainLogos(c), cls, c?.name);
const WALLET_ICON = LOGO_DIR + "wallet.svg";

/* ---------- state ---------- */
const S = {
  tab: "home",
  chains: [], chainById: new Map(), tokens: new Map(), // chainId -> token[]
  from: { chainId: C.DEFAULT_FROM_CHAIN, token: null },
  to: { chainId: C.DEFAULT_TO_CHAIN, token: null },
  slippage: C.DEFAULT_SLIPPAGE,
  evm: null,   // {provider, info, address}
  sol: null,   // {provider, name, icon, address}
  evmWallets: new Map(), // rdns -> {info, provider}
  quote: null, quoteErr: "", loading: false, busy: false,
  access: null, nxtBal: 0, gateMsg: "", // NXT holder gate: null = no wallet, "checking", true, false
  fromBalRaw: null,
  picking: null, pickChain: null,
};

/* ---------- utils ---------- */
function parseUnits(str, dec) {
  str = String(str).trim().replace(/,/g, "");
  if (!/^\d*\.?\d*$/.test(str) || str === "" || str === ".") return 0n;
  const [w, f = ""] = str.split(".");
  return BigInt((w || "0") + f.padEnd(dec, "0").slice(0, dec));
}
function formatUnits(v, dec) {
  v = BigInt(v); const neg = v < 0n; if (neg) v = -v;
  const s = v.toString().padStart(dec + 1, "0");
  const w = s.slice(0, s.length - dec), f = s.slice(s.length - dec).replace(/0+$/, "");
  return (neg ? "-" : "") + w + (f ? "." + f : "");
}
function fmt(n, max = 6) {
  n = Number(n); if (!isFinite(n)) return "—";
  if (n === 0) return "0";
  if (Math.abs(n) < 1e-6) return "<0.000001";
  return n.toLocaleString("en-US", { maximumFractionDigits: n >= 1000 ? 2 : n >= 1 ? 4 : max });
}
const usd = (n) => "$" + (Number(n) || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const short = (a) => a ? a.slice(0, 5) + "…" + a.slice(-4) : "";
const hex = (n) => "0x" + BigInt(n).toString(16);
const isNative = (t) => t && (t.address === EVM_NATIVE || t.address === "11111111111111111111111111111111" || t.address === "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
const chainType = (id) => (S.chainById.get(Number(id)) || {}).chainType;
const addrFor = (id) => chainType(id) === "SVM" ? S.sol?.address : S.evm?.address;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function toast(msg, err = false, ms = 4500) {
  const t = $("toast"); t.textContent = msg; t.className = "toast" + (err ? " err" : "");
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add("hidden"), ms);
}
async function api(path, params) {
  const url = new URL(API + path);
  if (params) Object.entries(params).forEach(([k, v]) => v !== undefined && v !== null && v !== "" && url.searchParams.set(k, v));
  const headers = C.LIFI_API_KEY ? { "x-lifi-api-key": C.LIFI_API_KEY } : {};
  const r = await fetch(url, { headers });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || `Request failed (${r.status})`);
  return j;
}
async function rpc(url, method, params) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
  const j = await r.json(); if (j.error) throw new Error(j.error.message); return j.result;
}
const evmRpcUrl = (id) => (S.chainById.get(Number(id))?.metamask?.rpcUrls || [])[0];
const pad32 = (h) => h.replace(/^0x/, "").toLowerCase().padStart(64, "0");

/* ---------- balances ---------- */
async function evmBalance(chainId, token, owner) {
  const url = evmRpcUrl(chainId); if (!url || !owner) return null;
  if (isNative(token)) return BigInt(await rpc(url, "eth_getBalance", [owner, "latest"]));
  const data = "0x70a08231" + pad32(owner);
  const res = await rpc(url, "eth_call", [{ to: token.address, data }, "latest"]);
  return BigInt(res && res !== "0x" ? res : 0);
}
async function solBalance(token, owner) {
  if (!owner) return null;
  if (isNative(token)) return BigInt((await rpc(C.SOLANA_RPC, "getBalance", [owner])).value);
  const res = await rpc(C.SOLANA_RPC, "getTokenAccountsByOwner", [owner, { mint: token.address }, { encoding: "jsonParsed" }]);
  return res.value.reduce((a, acc) => a + BigInt(acc.account.data.parsed.info.tokenAmount.amount), 0n);
}
async function balanceOf(chainId, token) {
  const owner = addrFor(chainId); if (!owner || !token) return null;
  try { return chainType(chainId) === "SVM" ? await solBalance(token, owner) : await evmBalance(chainId, token, owner); }
  catch { return null; }
}
async function refreshLegBalances() {
  const [fb, tb] = await Promise.all([balanceOf(S.from.chainId, S.from.token), balanceOf(S.to.chainId, S.to.token)]);
  S.fromBalRaw = fb;
  $("fromBal").textContent = fb == null ? "" : "Balance " + fmt(formatUnits(fb, S.from.token.decimals));
  $("toBal").textContent = tb == null ? "" : "Balance " + fmt(formatUnits(tb, S.to.token.decimals));
  renderAction();
}

/* ---------- data loading ---------- */
async function loadChains() {
  const j = await api("/chains", { chainTypes: "EVM,SVM" });
  S.chains = j.chains.sort((a, b) => (a.id === SOL_ID ? -1 : 0) || a.name.localeCompare(b.name));
  const pri = [1, 8453, SOL_ID, 42161, 56, 137, 10, 43114];
  S.chains.sort((a, b) => ((pri.indexOf(a.id) + 1 || 99) - (pri.indexOf(b.id) + 1 || 99)) || a.name.localeCompare(b.name));
  S.chains.forEach((c) => S.chainById.set(c.id, c));
  $("netCount").textContent = S.chains.length + " chains";
  $("searchBtn").querySelector("span").textContent = `Search tokens on ${S.chains.length} chains`;
}
async function tokensFor(chainId) {
  chainId = Number(chainId);
  if (S.tokens.has(chainId)) return S.tokens.get(chainId);
  const j = await api("/tokens", { chains: chainId, chainTypes: "EVM,SVM" });
  const list = (j.tokens[chainId] || []).sort((a, b) => (isNative(b) - isNative(a)) || (Number(b.priceUSD || 0) > 0) - (Number(a.priceUSD || 0) > 0));
  S.tokens.set(chainId, list); return list;
}
async function defaultTokens(chainId, preferStable) {
  const list = await tokensFor(chainId);
  const native = list.find(isNative) || list[0];
  const stable = list.find((t) => t.symbol === "USDC") || list.find((t) => t.symbol === "USDT") || list[1];
  return preferStable ? stable : native;
}

/* ---------- render ---------- */
function renderLegs() {
  for (const side of ["from", "to"]) {
    const leg = S[side], c = S.chainById.get(Number(leg.chainId)), t = leg.token;
    $(side + "TokBtn").innerHTML = t ? `<span class="ico-wrap">${tokImg(t, leg.chainId)}${c ? chainImg(c, "sub") : ""}</span><span>${esc(t.symbol)}</span>` : "<span>Select</span>";
    $(side + "ChainTag").textContent = c ? "on " + c.name : "";
  }
  $("swapTitle").textContent = S.tab === "bridge" ? "Bridge" : "Swap";
}
function renderQuote() {
  const q = S.quote, box = $("quoteBox");
  const amt = Number($("fromAmount").value || 0);
  $("fromUsd").textContent = usd(amt * Number(S.from.token?.priceUSD || 0));
  if (!q) { box.classList.add("hidden"); $("toAmount").value = ""; $("toUsd").textContent = "$0.00"; return; }
  const e = q.estimate, ft = q.action.fromToken, tt = q.action.toToken;
  const out = Number(formatUnits(e.toAmount, tt.decimals));
  const inn = Number(formatUnits(q.action.fromAmount, ft.decimals));
  $("toAmount").value = fmt(out);
  $("toUsd").textContent = usd(e.toAmountUSD || out * Number(tt.priceUSD || 0));
  $("qRate").textContent = `1 ${ft.symbol} ≈ ${fmt(out / inn)} ${tt.symbol}`;
  const gas = (e.gasCosts || []).reduce((a, g) => a + Number(g.amountUSD || 0), 0);
  $("qGas").textContent = gas ? usd(gas) : "—";
  $("qMin").textContent = `${fmt(formatUnits(e.toAmountMin, tt.decimals))} ${tt.symbol}`;
  const steps = (q.includedSteps || []).map((s) => s.toolDetails?.name || s.tool).filter(Boolean);
  $("qRoute").textContent = steps.length ? [...new Set(steps)].join(" → ") : (q.toolDetails?.name || q.tool);
  $("qTime").textContent = e.executionDuration ? (e.executionDuration < 60 ? `~${e.executionDuration}s` : `~${Math.round(e.executionDuration / 60)} min`) : "—";
  box.classList.remove("hidden");
}
function renderAction() {
  const b = $("actionBtn"); b.disabled = false;
  const need = chainType(S.from.chainId) === "SVM" ? "Solana" : "EVM";
  const amt = $("fromAmount").value;
  if (S.busy) { b.textContent = S.busy; b.disabled = true; return; }
  if (!addrFor(S.from.chainId)) { b.textContent = `Connect ${need} Wallet`; return; }
  if (!addrFor(S.to.chainId)) { b.textContent = `Connect ${chainType(S.to.chainId) === "SVM" ? "Solana" : "EVM"} wallet to receive`; return; }
  b.dataset.mode = "";
  if (S.access === "checking") { b.textContent = `Checking ${C.NXT_SYMBOL} balance…`; b.disabled = true; return; }
  if (!canTrade()) { b.textContent = S.gateMsg && !nxtList().length ? S.gateMsg : `Hold ${C.NXT_SYMBOL} to unlock · Buy ${C.NXT_SYMBOL}`; b.dataset.mode = "buy"; b.disabled = !nxtList().length; return; }
  if (!S.from.token || !S.to.token) { b.textContent = "Select tokens"; b.disabled = true; return; }
  if (!amt || Number(amt) <= 0) { b.textContent = "Enter an amount"; b.disabled = true; return; }
  if (S.fromBalRaw != null && parseUnits(amt, S.from.token.decimals) > S.fromBalRaw) { b.textContent = `Insufficient ${S.from.token.symbol}`; b.disabled = true; return; }
  if (S.loading) { b.textContent = "Finding best route…"; b.disabled = true; return; }
  if (S.quoteErr) { b.textContent = S.quoteErr.length > 60 ? "No route found" : S.quoteErr; b.disabled = true; return; }
  if (!S.quote) { b.textContent = "Get quote"; return; }
  b.textContent = buyingNxt() && S.access !== true ? `Buy ${C.NXT_SYMBOL}` : S.from.chainId === S.to.chainId ? "Swap" : "Bridge";
}

/* ---------- NXT holder gate ---------- */
const nxtList = () => (C.NXT_TOKENS || []).filter((t) => t.address && !/^PASTE/i.test(t.address));
const isNxt = (chainId, token) => !!token && nxtList().some((n) => Number(n.chainId) === Number(chainId) && n.address.toLowerCase() === String(token.address).toLowerCase());
const buyingNxt = () => isNxt(S.to.chainId, S.to.token);
const canTrade = () => S.access === true || buyingNxt();
let gateSeq = 0;
async function checkAccess() {
  const seq = ++gateSeq;
  if (!S.evm && !S.sol) { S.access = null; S.nxtBal = 0; renderGate(); return null; }
  const list = nxtList();
  if (!list.length) { S.access = false; S.gateMsg = `${C.NXT_SYMBOL} token not set up yet`; renderGate(); return false; }
  S.access = "checking"; S.gateMsg = ""; renderGate();
  let total = 0, checked = 0, failed = 0;
  await Promise.all(list.map(async (n) => {
    const svm = Number(n.chainId) === SOL_ID;
    const owner = svm ? S.sol?.address : S.evm?.address;
    if (!owner) return;
    checked++;
    try {
      const raw = svm ? await solBalance(n, owner) : await evmBalance(n.chainId, n, owner);
      if (raw == null) throw new Error("no rpc");
      total += Number(formatUnits(raw, n.decimals ?? 18));
    } catch { failed++; }
  }));
  if (seq !== gateSeq) return S.access;
  S.nxtBal = total;
  S.access = total > Number(C.NXT_MIN_BALANCE || 0);
  if (!S.access) {
    if (!checked) S.gateMsg = `Connect the ${list.some((n) => Number(n.chainId) === SOL_ID) && !list.some((n) => Number(n.chainId) !== SOL_ID) ? "Solana" : "EVM"} wallet that holds your ${C.NXT_SYMBOL}`;
    else if (failed === checked) S.gateMsg = `Couldn't check your ${C.NXT_SYMBOL} balance — tap Recheck`;
  }
  renderGate(); return S.access;
}
function renderGate() {
  const box = $("gateBox"); const sym = esc(C.NXT_SYMBOL);
  if (S.access === null) box.innerHTML = "";
  else if (S.access === "checking") box.innerHTML = `<div class="gate-pill">Checking ${sym} balance…</div>`;
  else if (S.access === true) box.innerHTML = `<div class="gate-pill ok">✓ ${sym} holder · ${fmt(S.nxtBal)} ${sym} · Swaps unlocked</div>`;
  else box.innerHTML = `<div class="gate-lock"><div class="lock-ico">🔒</div><div class="gate-txt"><b>Hold any amount of ${sym} to unlock</b>
      <small>${esc(S.gateMsg) || `NXT DEX is for ${sym} holders, with no platform fee. Buy a little ${sym} to get in.`}</small></div>
      <div class="gate-btns">${nxtList().length ? `<button class="btn-sm" data-gate="buy">Buy ${sym}</button>` : ""}<button class="btn-sm ghost" data-gate="recheck">Recheck</button></div></div>`;
  $("swapCard").classList.toggle("locked", S.access !== null && !canTrade());
  renderAction();
}
async function buyNxt() {
  const list = nxtList(); if (!list.length) return toast(`${C.NXT_SYMBOL} token isn't configured yet`, true);
  const n = list.find((x) => (Number(x.chainId) === SOL_ID ? S.sol : S.evm)) || list[0];
  const chainId = Number(n.chainId);
  let token;
  try { token = await api("/token", { chain: chainId, token: n.address }); }
  catch { token = { chainId, address: n.address, decimals: n.decimals ?? 18, symbol: C.NXT_SYMBOL, name: C.NXT_SYMBOL, logoURI: "", priceUSD: "0" }; }
  S.to = { chainId, token };
  S.from = { chainId, token: await defaultTokens(chainId, false) };
  setTab("swap"); refreshLegBalances(); scheduleQuote(50);
  toast(`Buy any amount of ${C.NXT_SYMBOL} to unlock NXT DEX`);
}
function renderConnect() {
  const any = S.evm || S.sol;
  const b = $("connectBtn");
  b.innerHTML = any ? `<span class="avatar"></span><span><code>${esc(short(S.evm?.address || S.sol?.address))}</code>${S.evm && S.sol ? ' <small class="muted">+1</small>' : ""}</span>` : "Connect";
  b.classList.toggle("on", !!any);
  $("wEmpty").classList.toggle("hidden", !!any);
  $("wFull").classList.toggle("hidden", !any);
  $("wAccounts").innerHTML = [
    S.evm && `<div class="acct">${img([S.evm.info.icon, WALLET_ICON], "ico", S.evm.info.name)}<span>${esc(S.evm.info.name)}</span><code>${short(S.evm.address)}</code><button class="x" data-disc="evm" title="Disconnect">✕</button></div>`,
    S.sol && `<div class="acct">${img([S.sol.icon, WALLET_ICON], "ico", S.sol.name)}<span>${esc(S.sol.name)} · Solana</span><code>${short(S.sol.address)}</code><button class="x" data-disc="sol" title="Disconnect">✕</button></div>`,
  ].filter(Boolean).join("");
  renderAction();
}

/* ---------- quote ---------- */
let qTimer, qSeq = 0;
function scheduleQuote(delay = 550) { clearTimeout(qTimer); qTimer = setTimeout(getQuote, delay); }
async function getQuote() {
  const seq = ++qSeq, amtStr = $("fromAmount").value;
  S.quote = null; S.quoteErr = "";
  const ft = S.from.token, tt = S.to.token;
  const amount = ft ? parseUnits(amtStr, ft.decimals) : 0n;
  if (!ft || !tt || amount <= 0n) { S.loading = false; renderQuote(); renderAction(); return; }
  if (S.from.chainId === S.to.chainId && ft.address === tt.address) { S.quoteErr = "Pick two different tokens"; renderQuote(); renderAction(); return; }
  S.loading = true; renderQuote(); renderAction();
  const fromAddr = addrFor(S.from.chainId) || (chainType(S.from.chainId) === "SVM" ? "DDmSXv1rnU7W2vJBoAy7GzUJ7hpsEBzmBJyY5RTa7Zhx" : "0x552008c0f6870c2f77e5cC1d2eb9bdff03e30Ea0"); // placeholder address used only to preview a price before connecting
  try {
    const q = await api("/quote", {
      fromChain: S.from.chainId, toChain: S.to.chainId, fromToken: ft.address, toToken: tt.address,
      fromAmount: amount.toString(), fromAddress: fromAddr, toAddress: addrFor(S.to.chainId) || undefined,
      slippage: S.slippage, integrator: C.INTEGRATOR, order: "CHEAPEST",
    });
    if (seq !== qSeq) return;
    S.quote = q;
  } catch (e) { if (seq !== qSeq) return; S.quoteErr = e.message || "No route found"; }
  S.loading = false; renderQuote(); renderAction();
}
setInterval(() => { if (S.quote && !S.busy && document.visibilityState === "visible") getQuote(); }, 30000);

/* ---------- EVM wallets (EIP-6963 + legacy) ---------- */
window.addEventListener("eip6963:announceProvider", (e) => {
  const { info, provider } = e.detail; S.evmWallets.set(info.rdns || info.uuid, { info, provider }); renderWalletList();
});
function discoverEvm() {
  window.dispatchEvent(new Event("eip6963:requestProvider"));
  setTimeout(() => {
    if (!S.evmWallets.size && window.ethereum) S.evmWallets.set("injected", { info: { name: window.ethereum.isCoinbaseWallet ? "Base Wallet" : window.ethereum.isPhantom ? "Phantom" : "Browser Wallet", icon: "" }, provider: window.ethereum });
    renderWalletList();
  }, 250);
}
async function connectEvm(key) {
  const w = S.evmWallets.get(key); if (!w) return;
  try {
    const [address] = await w.provider.request({ method: "eth_requestAccounts" });
    S.evm = { ...w, address };
    w.provider.on?.("accountsChanged", (a) => { if (!a.length) S.evm = null; else S.evm.address = a[0]; onWalletChange(); });
    toast(`Connected ${w.info.name}`); closeModals(); onWalletChange();
  } catch (e) { toast(e.message || "Connection rejected", true); }
}
async function ensureEvmChain(chainId) {
  const p = S.evm.provider, want = hex(chainId);
  const cur = await p.request({ method: "eth_chainId" });
  if (BigInt(cur) === BigInt(chainId)) return;
  try { await p.request({ method: "wallet_switchEthereumChain", params: [{ chainId: want }] }); }
  catch (e) {
    if (e.code !== 4902 && e?.data?.originalError?.code !== 4902) throw e;
    const m = S.chainById.get(Number(chainId)).metamask;
    await p.request({ method: "wallet_addEthereumChain", params: [{ ...m, chainId: want }] });
  }
}
async function waitReceipt(hash) {
  for (let i = 0; i < 180; i++) {
    const r = await S.evm.provider.request({ method: "eth_getTransactionReceipt", params: [hash] }).catch(() => null);
    if (r) { if (r.status === "0x0") throw new Error("Transaction reverted"); return r; }
    await sleep(2000);
  }
  throw new Error("Timed out waiting for confirmation");
}

/* ---------- Solana wallets ---------- */
// Real wallet icons via the Wallet Standard (Phantom, Solflare, Backpack all register one)
const stdIcons = {};
const stdRegister = (...ws) => { ws.forEach((w) => { if (w?.name && w.icon) stdIcons[w.name.toLowerCase()] = w.icon; }); return () => {}; };
window.addEventListener("wallet-standard:register-wallet", (e) => { try { e.detail({ register: stdRegister }); } catch {} });
try { window.dispatchEvent(new CustomEvent("wallet-standard:app-ready", { detail: { register: stdRegister } })); } catch {}
const solIcon = (key, fallback) => stdIcons[key] || fallback;
function solWallets() {
  const list = [];
  const ph = window.phantom?.solana; if (ph?.isPhantom) list.push({ key: "phantom", name: "Phantom", icon: solIcon("phantom", "https://phantom.com/favicon.ico"), provider: ph });
  if (window.solflare?.isSolflare) list.push({ key: "solflare", name: "Solflare", icon: solIcon("solflare", "https://solflare.com/favicon.ico"), provider: window.solflare });
  if (window.backpack?.solana) list.push({ key: "backpack", name: "Backpack", icon: solIcon("backpack", "https://backpack.app/favicon.ico"), provider: window.backpack.solana });
  return list;
}
async function connectSol(key) {
  const w = solWallets().find((x) => x.key === key); if (!w) return;
  try {
    const res = await w.provider.connect();
    const pk = res?.publicKey || w.provider.publicKey;
    S.sol = { ...w, address: pk.toString() };
    w.provider.on?.("accountChanged", (pk2) => { if (pk2) S.sol.address = pk2.toString(); else S.sol = null; onWalletChange(); });
    toast(`Connected ${w.name}`); closeModals(); onWalletChange();
  } catch (e) { toast(e.message || "Connection rejected", true); }
}
function b64ToBytes(b64) { return Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)); }

function renderWalletList() {
  const evm = [...S.evmWallets.entries()];
  $("walEvm").innerHTML = evm.length ? evm.map(([k, w]) =>
    `<button class="wal" data-evm="${esc(k)}">${img([w.info.icon, WALLET_ICON], "ico", w.info.name)}${esc(w.info.name)}${S.evm?.info.name === w.info.name ? '<span class="tag">Connected</span>' : ""}</button>`).join("")
    : `<p class="muted small">No EVM wallet found. Install MetaMask, Phantom, Rabby or Base Wallet.</p>`;
  const sol = solWallets();
  $("walSol").innerHTML = sol.length ? sol.map((w) =>
    `<button class="wal" data-sol="${w.key}">${img([w.icon, WALLET_ICON], "ico", w.name)}${esc(w.name)}${S.sol?.key === w.key ? '<span class="tag">Connected</span>' : ""}</button>`).join("")
    : `<p class="muted small">No Solana wallet found. Install <a href="https://phantom.com" target="_blank" rel="noopener">Phantom</a>.</p>`;
}
function onWalletChange() { renderConnect(); checkAccess(); refreshLegBalances(); scheduleQuote(100); loadPortfolio(); }

/* ---------- execute swap ---------- */
async function execute() {
  if (!addrFor(S.from.chainId) || !addrFor(S.to.chainId)) return openWalletModal();
  if (!canTrade()) return buyNxt();
  if (!buyingNxt() && (await checkAccess()) !== true) return toast(`You need to hold ${C.NXT_SYMBOL} to swap`, true);
  if (!S.quote) return getQuote();
  const q = S.quote, ft = q.action.fromToken;
  const setBusy = (t) => { S.busy = t; renderAction(); };
  try {
    let hash;
    if (chainType(S.from.chainId) === "SVM") {
      setBusy("Confirm in wallet…");
      const tx = window.solanaWeb3.VersionedTransaction.deserialize(b64ToBytes(q.transactionRequest.data));
      const res = await S.sol.provider.signAndSendTransaction(tx);
      hash = res.signature || res;
    } else {
      setBusy("Switching network…");
      await ensureEvmChain(S.from.chainId);
      const from = S.evm.address, amount = BigInt(q.action.fromAmount);
      if (!isNative(ft) && q.estimate.approvalAddress) {
        const allowance = BigInt(await rpc(evmRpcUrl(S.from.chainId), "eth_call", [{ to: ft.address, data: "0xdd62ed3e" + pad32(from) + pad32(q.estimate.approvalAddress) }, "latest"]) || 0);
        if (allowance < amount) {
          setBusy(`Approve ${ft.symbol} in wallet…`);
          const ah = await S.evm.provider.request({ method: "eth_sendTransaction", params: [{ from, to: ft.address, data: "0x095ea7b3" + pad32(q.estimate.approvalAddress) + pad32(hex(amount)) }] });
          setBusy("Waiting for approval…");
          await waitReceipt(ah);
          await getQuote(); // refresh calldata after approval
          if (!S.quote) throw new Error(S.quoteErr || "Quote expired");
        }
      }
      const tr = S.quote.transactionRequest;
      setBusy("Confirm swap in wallet…");
      hash = await S.evm.provider.request({ method: "eth_sendTransaction", params: [{ from, to: tr.to, data: tr.data, value: tr.value || "0x0", ...(tr.gasLimit ? { gas: tr.gasLimit } : {}) }] });
    }
    const item = {
      hash, time: Date.now(), fromChain: S.from.chainId, toChain: S.to.chainId, bridge: S.quote.tool,
      fromSym: ft.symbol, fromTok: { address: ft.address, symbol: ft.symbol, logoURI: ft.logoURI }, toSym: S.quote.action.toToken.symbol,
      fromAmt: formatUnits(S.quote.action.fromAmount, ft.decimals), toAmt: formatUnits(S.quote.estimate.toAmount, S.quote.action.toToken.decimals),
      status: "PENDING",
    };
    addActivity(item); toast("Transaction submitted ✓");
    $("fromAmount").value = ""; S.quote = null; renderQuote();
    trackStatus(item);
    if (isNxt(item.toChain, S.to.token)) setTimeout(checkAccess, 15000);
  } catch (e) {
    toast(e?.message?.includes("rejected") || e?.code === 4001 ? "Transaction cancelled" : (e.message || "Swap failed"), true);
  } finally { S.busy = false; renderAction(); refreshLegBalances(); }
}

/* ---------- activity ---------- */
const ACT_KEY = "nxtdex_activity";
function loadAct() { try { return JSON.parse(localStorage.getItem(ACT_KEY) || "[]"); } catch { return []; } }
function saveAct(a) { try { localStorage.setItem(ACT_KEY, JSON.stringify(a.slice(0, 100))); } catch {} }
function addActivity(item) { const a = loadAct(); a.unshift(item); saveAct(a); renderActivity(); }
function updateActivity(hash, patch) { const a = loadAct(); const i = a.findIndex((x) => x.hash === hash); if (i >= 0) { Object.assign(a[i], patch); saveAct(a); renderActivity(); } }
function explorer(chainId, hash) {
  if (Number(chainId) === SOL_ID) return `https://solscan.io/tx/${hash}`;
  const b = (S.chainById.get(Number(chainId))?.metamask?.blockExplorerUrls || [])[0];
  return b ? b.replace(/\/$/, "") + "/tx/" + hash : `https://scan.li.fi/tx/${hash}`;
}
function renderActivity() {
  const a = loadAct();
  $("actList").innerHTML = a.length ? a.map((x) => {
    const fc = S.chainById.get(Number(x.fromChain)), tc = S.chainById.get(Number(x.toChain));
    return `<div class="act"><span class="ico-wrap">${x.fromTok ? tokImg(x.fromTok, x.fromChain) : chainImg(fc)}${x.fromTok ? chainImg(fc, "sub") : ""}</span><div><b>${fmt(x.fromAmt)} ${esc(x.fromSym)} → ${fmt(x.toAmt)} ${esc(x.toSym)}</b><br>
      <small class="muted">${esc(fc?.name || "")}${x.fromChain !== x.toChain ? " → " + esc(tc?.name || "") : ""} · ${new Date(x.time).toLocaleString()} · <a href="${esc(explorer(x.fromChain, x.hash))}" target="_blank" rel="noopener">View</a></small></div>
      <span class="st ${esc(x.status)}">${esc(x.status)}</span></div>`;
  }).join("") : `<p class="muted">No swaps yet.</p>`;
}
async function trackStatus(item) {
  for (let i = 0; i < 240; i++) {
    await sleep(i < 10 ? 4000 : 10000);
    try {
      const s = await api("/status", { txHash: item.hash, fromChain: item.fromChain, toChain: item.toChain, bridge: item.fromChain !== item.toChain ? item.bridge : undefined });
      if (s.status === "DONE" || s.status === "FAILED") {
        updateActivity(item.hash, { status: s.status });
        toast(s.status === "DONE" ? `${item.fromSym} → ${item.toSym} complete ✓` : "Swap failed — funds stay in your wallet or are refunded", s.status === "FAILED");
        refreshLegBalances(); loadPortfolio(); checkAccess(); return;
      }
    } catch {}
  }
}
function resumeTracking() { loadAct().filter((x) => x.status === "PENDING" && Date.now() - x.time < 864e5).forEach(trackStatus); }

/* ---------- portfolio ---------- */
let portSeq = 0;
async function loadPortfolio() {
  const seq = ++portSeq;
  if (!S.evm && !S.sol) { $("wList").innerHTML = `<p class="muted pad">Connect a wallet to see your tokens.</p>`; $("holdCount").textContent = ""; return; }
  $("wList").innerHTML = `<p class="muted">Loading balances…</p>`;
  const jobs = [];
  const watch = (sym) => ["USDC", "USDT", "WETH", "WBTC", "DAI", "cbBTC"].includes(sym);
  if (S.evm) for (const id of C.PORTFOLIO_CHAINS) {
    if (!S.chainById.has(id)) continue;
    jobs.push(tokensFor(id).then((list) => Promise.all(list.filter((t) => (isNative(t) || watch(t.symbol)) && !isNxt(id, t)).slice(0, 6).concat(list.filter((t) => isNxt(id, t)))
      .map(async (t) => ({ t, c: S.chainById.get(id), raw: await evmBalance(id, t, S.evm.address).catch(() => null) })))).catch(() => []));
  }
  if (S.sol && S.chainById.has(SOL_ID)) jobs.push(tokensFor(SOL_ID).then((list) => Promise.all(list.filter((t) => isNative(t) || ["USDC", "USDT"].includes(t.symbol)).slice(0, 3)
    .map(async (t) => ({ t, c: S.chainById.get(SOL_ID), raw: await solBalance(t, S.sol.address).catch(() => null) })))).catch(() => []));
  for (const n of nxtList()) {
    const svm = Number(n.chainId) === SOL_ID, owner = svm ? S.sol?.address : S.evm?.address;
    if (!owner || !S.chainById.has(Number(n.chainId))) continue;
    jobs.push(tokensFor(n.chainId).catch(() => []).then(async (list) => {
      if (list.some((t) => String(t.address).toLowerCase() === n.address.toLowerCase())) return []; // already covered below
      let t = { chainId: Number(n.chainId), address: n.address, decimals: n.decimals ?? 18, symbol: C.NXT_SYMBOL, name: C.NXT_SYMBOL, priceUSD: "0" };
      try { t = await api("/token", { chain: n.chainId, token: n.address }); } catch {}
      return [{ t, c: S.chainById.get(Number(n.chainId)), raw: await (svm ? solBalance(t, owner) : evmBalance(n.chainId, t, owner)).catch(() => null) }];
    }));
  }
  const rows = (await Promise.all(jobs)).flat().filter((r) => r.raw && r.raw > 0n)
    .map((r) => { const amt = Number(formatUnits(r.raw, r.t.decimals)); return { ...r, amt, val: amt * Number(r.t.priceUSD || 0) }; })
    .sort((a, b) => b.val - a.val);
  if (seq !== portSeq) return;
  const total = rows.reduce((a, r) => a + r.val, 0);
  $("wTotal").textContent = usd(total);
  $("holdCount").textContent = rows.length ? rows.length + " assets" : "";
  $("wSub").textContent = (() => { const n = new Set(rows.map((r) => r.c.id)).size; return `across ${n} chain${n === 1 ? "" : "s"}`; })();
  const html = rows.length ? rows.map((r) => `<div class="hold"><span class="ico-wrap">${tokImg(r.t, r.c.id)}${chainImg(r.c, "sub")}</span><div class="nm"><b>${esc(r.t.symbol)}</b><small>${esc(r.c.name)}</small></div>
    <div class="vl"><b>${usd(r.val)}</b><small>${fmt(r.amt)} ${esc(r.t.symbol)}</small></div></div>`).join("")
    : `<p class="muted pad">No balances found on the tracked chains.</p>`;
  $("wList").innerHTML = html;
}

/* ---------- token modal ---------- */
async function openTokModal(side) {
  S.picking = side; S.pickChain = S[side].chainId;
  $("tokModal").classList.remove("hidden"); $("tokSearch").value = ""; renderChainGrid(); await renderTokList();
  $("tokSearch").focus();
}
function renderChainGrid() {
  $("chainGrid").innerHTML = S.chains.map((c) => `<button data-chain="${c.id}" class="${c.id === Number(S.pickChain) ? "on" : ""}">${chainImg(c, "")}${esc(c.name)}</button>`).join("");
}
async function renderTokList() {
  const box = $("tokList"); box.innerHTML = `<p class="muted">Loading tokens…</p>`;
  let list; try { list = await tokensFor(S.pickChain); } catch (e) { box.innerHTML = `<p class="muted">Couldn't load tokens: ${esc(e.message)}</p>`; return; }
  const q = $("tokSearch").value.trim().toLowerCase();
  let res = q ? list.filter((t) => t.symbol.toLowerCase().includes(q) || (t.name || "").toLowerCase().includes(q) || t.address.toLowerCase() === q) : list;
  if (!res.length && q.length > 30) {
    try { const t = await api("/token", { chain: S.pickChain, token: $("tokSearch").value.trim() }); res = [t]; } catch {}
  }
  box.innerHTML = res.slice(0, 250).map((t, i) => `<button class="tok-row" data-i="${list.indexOf(t) >= 0 ? list.indexOf(t) : "x" + i}"><span class="ico-wrap">${tokImg(t, S.pickChain)}</span><div><b>${esc(t.symbol)}</b><small>${esc(t.name)}</small></div><span class="px">${Number(t.priceUSD) ? usd(t.priceUSD) : ""}</span></button>`).join("")
    || `<p class="muted">No tokens match. Paste a contract address to import.</p>`;
  box._extra = res;
}
async function pickToken(t) {
  const side = S.picking; S[side].chainId = Number(S.pickChain); S[side].token = t;
  if (S.tab === "swap" && side === "from" && S.to.chainId !== S[side].chainId) { S.to.chainId = S[side].chainId; S.to.token = await defaultTokens(S.to.chainId, true); }
  if (S.tab === "swap" && side === "to" && S.from.chainId !== S[side].chainId) { S.from.chainId = S[side].chainId; S.from.token = await defaultTokens(S.from.chainId, false); }
  closeModals(); renderLegs(); refreshLegBalances(); scheduleQuote(50); renderAction();
}

/* ---------- modals / tabs ---------- */
function closeModals() { document.querySelectorAll(".modal").forEach((m) => m.classList.add("hidden")); }
function openWalletModal() { discoverEvm(); renderWalletList(); $("walModal").classList.remove("hidden"); }
function setTab(tab) {
  S.tab = tab;
  document.querySelectorAll("[data-nav] button").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  const swapLike = tab === "swap" || tab === "bridge";
  $("view-home").classList.toggle("hidden", tab !== "home");
  $("view-swap").classList.toggle("hidden", !swapLike);
  $("view-activity").classList.toggle("hidden", tab !== "activity");
  $("view-explore").classList.toggle("hidden", tab !== "explore");
  const card = $("swapCard");
  (tab === "home" ? $("slotHome") : $("slotSwap")).appendChild(card);
  if (tab === "bridge" && S.from.chainId === S.to.chainId) {
    const alt = S.from.chainId === 8453 ? 42161 : 8453;
    S.to.chainId = alt; defaultTokens(alt, true).then((t) => { S.to.token = t; renderLegs(); refreshLegBalances(); scheduleQuote(50); });
  }
  if (tab === "activity") renderActivity();
  if (tab === "explore") loadExplore();
  if (tab === "home") loadPortfolio();
  renderLegs(); window.scrollTo({ top: 0 });
}
function openReceive() {
  const rows = [
    S.evm && { n: "EVM address", s: "Ethereum, Base, Arbitrum, BNB, Polygon + all EVM chains", a: S.evm.address },
    S.sol && { n: "Solana address", s: "SOL and SPL tokens", a: S.sol.address },
  ].filter(Boolean);
  $("recvList").innerHTML = rows.length ? rows.map((r) => `<div class="recv"><span class="avatar"></span><div><b>${r.n}</b><small class="muted">${r.s}</small><br><code>${esc(r.a)}</code></div>
    <button class="icon-btn" data-copy="${esc(r.a)}" title="Copy"><svg><use href="#i-copy"/></svg></button></div>`).join("") : `<p class="muted">Connect a wallet first.</p>`;
  $("recvModal").classList.remove("hidden");
}

/* ---------- explore (GeckoTerminal market data) ---------- */
const GT = (C.GECKO_BASE || "https://api.geckoterminal.com/api/v2");
const GT_NET = { eth: 1, base: 8453, solana: SOL_ID, arbitrum: 42161, bsc: 56, polygon_pos: 137, optimism: 10, avax: 43114 };
const GT_BY_CHAIN = Object.fromEntries(Object.entries(GT_NET).map(([k, v]) => [v, k]));
const GT_NAMES = { eth: "Ethereum", base: "Base", solana: "Solana", arbitrum: "Arbitrum", bsc: "BNB Chain", polygon_pos: "Polygon", optimism: "Optimism", avax: "Avalanche" };
const EX = { tab: "trending", net: "all", tf: "h24", page: 1, rows: [], loading: false, err: "", loadedKey: "" };
const gtCache = new Map();
async function gt(path, params = {}) {
  const url = new URL(GT + path);
  Object.entries(params).forEach(([k, v]) => v != null && url.searchParams.set(k, v));
  const key = url.toString(), hit = gtCache.get(key);
  if (hit && Date.now() - hit.t < 90_000) return hit.data; // stay under the free ~10 calls/min limit
  const headers = { accept: "application/json;version=20230302" };
  if (C.GECKO_API_KEY) headers["x-cg-pro-api-key"] = C.GECKO_API_KEY;
  const r = await fetch(key, { headers });
  if (r.status === 429) throw new Error("Market data is busy. Retrying in a minute.");
  if (!r.ok) throw new Error(`Market data unavailable (${r.status})`);
  const data = await r.json(); gtCache.set(key, { t: Date.now(), data }); return data;
}
function parsePools(json) {
  const inc = new Map((json.included || []).map((x) => [x.id, x]));
  return (json.data || []).map((p) => {
    const a = p.attributes || {}, bt = p.relationships?.base_token?.data?.id || "";
    const net = p.relationships?.network?.data?.id || bt.slice(0, bt.lastIndexOf("_"));
    const tok = inc.get(bt)?.attributes || {};
    const address = tok.address || bt.slice(bt.lastIndexOf("_") + 1);
    const ch = a.price_change_percentage || {};
    const tx = a.transactions?.h24 || {};
    return {
      key: net + ":" + address.toLowerCase(), net, chainId: GT_NET[net], address,
      symbol: tok.symbol || String(a.name || "").split(" / ")[0], name: tok.name || a.name || "",
      image: tok.image_url && !/missing/i.test(tok.image_url) ? tok.image_url : "",
      price: Number(a.base_token_price_usd) || 0,
      ch: { m5: +ch.m5 || 0, h1: +ch.h1 || 0, h6: +ch.h6 || 0, h24: +ch.h24 || 0 },
      vol: Number(a.volume_usd?.h24) || 0, liq: Number(a.reserve_in_usd) || 0,
      mcap: Number(a.market_cap_usd) || Number(a.fdv_usd) || 0,
      created: Date.parse(a.pool_created_at) || 0, buys: tx.buys || 0, sells: tx.sells || 0,
    };
  }).filter((r) => r.chainId); // only chains NXT DEX can trade
}
function exEndpoint(page) {
  const all = EX.net === "all", inc = { include: "base_token", page };
  if (EX.tab === "new") return [all ? "/networks/new_pools" : `/networks/${EX.net}/new_pools`, inc];
  if (EX.tab === "top" && !all) return [`/networks/${EX.net}/pools`, { ...inc, sort: "h24_volume_usd_desc" }];
  return [all ? "/networks/trending_pools" : `/networks/${EX.net}/trending_pools`, inc];
}
async function loadExplore(more = false) {
  const key = EX.tab + "|" + EX.net;
  if (!more && EX.loadedKey === key && EX.rows.length) return renderExplore();
  EX.page = more ? EX.page + 1 : 1; EX.loading = true; EX.err = "";
  if (!more) EX.rows = [];
  renderExplore();
  try {
    const [path, params] = exEndpoint(EX.page);
    const rows = parsePools(await gt(path, params));
    const seen = new Map(EX.rows.map((r) => [r.key, r]));
    rows.forEach((r, i) => { r.rank = EX.rows.length + i + 1; const prev = seen.get(r.key); if (!prev || r.liq > prev.liq) seen.set(r.key, prev ? { ...r, rank: prev.rank } : r); });
    EX.rows = [...seen.values()]; EX.loadedKey = key;
    if (!rows.length && more) EX.page--;
  } catch (e) { EX.err = e.message; if (more) EX.page--; }
  EX.loading = false; renderExplore();
}
const money = (n) => !n ? "—" : n >= 1e9 ? "$" + (n / 1e9).toFixed(2) + "B" : n >= 1e6 ? "$" + (n / 1e6).toFixed(2) + "M" : n >= 1e3 ? "$" + (n / 1e3).toFixed(1) + "K" : "$" + n.toFixed(0);
function price(n) {
  if (!n) return "—";
  if (n >= 1) return "$" + n.toLocaleString("en-US", { maximumFractionDigits: n >= 1000 ? 0 : 2 });
  if (n >= 0.0001) return "$" + n.toPrecision(3);
  const e = Math.floor(-Math.log10(n)) - 1; // leading zeros after "0."
  return `$0.0<sub>${e}</sub>${Math.round(n * 10 ** (e + 4))}`;
}
function age(t) {
  if (!t) return "—"; const s = (Date.now() - t) / 1000;
  return s < 3600 ? Math.max(1, Math.round(s / 60)) + "m" : s < 86400 ? Math.round(s / 3600) + "h" : s < 86400 * 60 ? Math.round(s / 86400) + "d" : s < 86400 * 365 ? Math.round(s / 86400 / 30) + "mo" : (s / 86400 / 365).toFixed(1).replace(/\.0$/, "") + "y";
}
function exFiltered() {
  const q = $("exSearch").value.trim().toLowerCase();
  const minLiq = +$("exLiq").value, minVol = +$("exVol").value, ageLim = +$("exAge").value, sort = $("exSort").value, tf = EX.tf;
  let rows = EX.rows.filter((r) =>
    (!q || r.symbol.toLowerCase().includes(q) || r.name.toLowerCase().includes(q) || r.address.toLowerCase() === q) &&
    r.liq >= minLiq && r.vol >= minVol &&
    (!ageLim || (ageLim > 0 ? Date.now() - r.created <= ageLim * 1000 : Date.now() - r.created >= -ageLim * 1000)));
  const by = { vol: (a, b) => b.vol - a.vol, chg: (a, b) => b.ch[tf] - a.ch[tf], liq: (a, b) => b.liq - a.liq, mcap: (a, b) => b.mcap - a.mcap, age: (a, b) => b.created - a.created };
  if (sort !== "default") rows.sort(by[sort]);
  else if (EX.tab === "gainers") rows.sort(by.chg);
  else if (EX.tab === "top") rows.sort(by.vol);
  else if (EX.tab === "new") rows.sort(by.age);
  else rows.sort((a, b) => a.rank - b.rank);
  return rows;
}
function renderExChains() {
  const nets = ["all", ...Object.keys(GT_NET)];
  $("exChains").innerHTML = nets.map((n) => {
    const c = n === "all" ? null : (S.chainById.get(GT_NET[n]) || { id: GT_NET[n], name: GT_NAMES[n] });
    return `<button data-net="${n}" class="${EX.net === n ? "on" : ""}">${c ? chainImg(c, "") : '<svg><use href="#i-explore"/></svg>'}${n === "all" ? "All chains" : esc(GT_NAMES[n])}</button>`;
  }).join("");
}
function renderExplore() {
  renderExChains();
  document.querySelectorAll("#exTabs [data-ex]").forEach((b) => b.classList.toggle("on", b.dataset.ex === EX.tab));
  document.querySelectorAll("#exTf [data-tf]").forEach((b) => b.classList.toggle("on", b.dataset.tf === EX.tf));
  $("exChgHead").textContent = { m5: "5m", h1: "1h", h6: "6h", h24: "24h" }[EX.tf];
  const box = $("exList");
  if (EX.loading && !EX.rows.length) { box.innerHTML = Array.from({ length: 8 }, () => '<div class="ex-row sk"><span></span><span></span><span></span><span></span></div>').join(""); }
  else if (EX.err && !EX.rows.length) box.innerHTML = `<p class="muted pad">${esc(EX.err)} <button class="btn-sm ghost" data-exretry>Retry</button></p>`;
  else {
    const rows = exFiltered();
    box.innerHTML = rows.length ? rows.map((r, i) => {
      const c = S.chainById.get(r.chainId) || { id: r.chainId, name: GT_NAMES[r.net] };
      const chg = r.ch[EX.tf], isNew = r.created && Date.now() - r.created < 86400e3;
      const risky = r.liq < 10000;
      return `<div class="ex-row" data-key="${esc(r.key)}">
        <span class="ex-rank">${i + 1}</span>
        <span class="ex-coin"><span class="ico-wrap">${tokImg({ address: r.address, symbol: r.symbol, logoURI: r.image }, r.chainId)}${chainImg(c, "sub")}</span>
          <span class="ex-nm"><b>${esc(r.symbol)}${isNew ? '<em class="tag new">NEW</em>' : ""}${risky ? '<em class="tag risk">LOW LIQ</em>' : ""}</b><small>${esc(r.name)} · ${esc(c.name)}</small></span></span>
        <span class="r ex-price">${price(r.price)}</span>
        <span class="r ex-chg ${chg >= 0 ? "up" : "down"}">${chg >= 0 ? "+" : ""}${chg.toFixed(Math.abs(chg) >= 100 ? 0 : 2)}%</span>
        <span class="r ex-vol" data-l="Vol">${money(r.vol)}</span>
        <span class="r ex-liq" data-l="Liq">${money(r.liq)}</span>
        <span class="r ex-mc" data-l="MC">${money(r.mcap)}</span>
        <span class="r ex-age" data-l="Age">${age(r.created)}</span>
        <span class="ex-meta">Vol ${money(r.vol)} · Liq ${money(r.liq)} · ${age(r.created)}</span>
        <span class="r ex-trade"><button class="btn-sm" data-trade="${esc(r.key)}">Trade</button></span>
      </div>`;
    }).join("") : `<p class="muted pad">No coins match these filters. Try lowering the liquidity or volume minimum.</p>`;
  }
  $("exMore").classList.toggle("hidden", !EX.rows.length || EX.page >= 10);
  $("exMore").textContent = EX.loading && EX.rows.length ? "Loading…" : "Load more";
  $("exMeta").textContent = EX.err && EX.rows.length ? EX.err : EX.rows.length ? `${exFiltered().length} of ${EX.rows.length} coins shown` : "";
}
async function tradeCoin(key) {
  const r = EX.rows.find((x) => x.key === key); if (!r) return;
  let token;
  try { token = await api("/token", { chain: r.chainId, token: r.address }); }
  catch { return toast(`${r.symbol} isn't routable on NXT DEX yet (no liquidity found by the router)`, true); }
  if (!token.logoURI && r.image) token.logoURI = r.image;
  S.to = { chainId: r.chainId, token };
  S.from = { chainId: r.chainId, token: await defaultTokens(r.chainId, false) };
  if (isNative(S.from.token) && isNative(token)) S.from.token = await defaultTokens(r.chainId, true);
  $("fromAmount").value = "";
  setTab("swap"); refreshLegBalances(); renderQuote(); renderAction();
  toast(`${token.symbol} on ${S.chainById.get(r.chainId)?.name || GT_NAMES[r.net]} loaded into Swap`);
}
setInterval(() => { if (S.tab === "explore" && document.visibilityState === "visible" && !EX.loading) { EX.loadedKey = ""; gtCache.clear(); loadExplore(); } }, 120_000);

/* ---------- events ---------- */
function bind() {
  $("exTabs").addEventListener("click", (e) => { const b = e.target.closest("[data-ex]"); if (!b) return; EX.tab = b.dataset.ex; if (EX.tab === "gainers") $("exSort").value = "default"; loadExplore(); });
  $("exChains").addEventListener("click", (e) => { const b = e.target.closest("[data-net]"); if (!b) return; EX.net = b.dataset.net; loadExplore(); });
  $("exTf").addEventListener("click", (e) => { const b = e.target.closest("[data-tf]"); if (!b) return; EX.tf = b.dataset.tf; renderExplore(); });
  ["exLiq", "exVol", "exAge", "exSort"].forEach((id) => $(id).addEventListener("change", renderExplore));
  let exT; $("exSearch").addEventListener("input", () => { clearTimeout(exT); exT = setTimeout(renderExplore, 150); });
  $("exMore").addEventListener("click", () => loadExplore(true));
  $("exList").addEventListener("click", (e) => { const t = e.target.closest("[data-trade]"); if (t) return tradeCoin(t.dataset.trade); if (e.target.closest("[data-exretry]")) { EX.loadedKey = ""; loadExplore(); } });
  document.querySelectorAll("[data-nav]").forEach((n) => n.addEventListener("click", (e) => { const b = e.target.closest("button[data-tab]"); if (b) setTab(b.dataset.tab); }));
  $("searchBtn").addEventListener("click", () => openTokModal("to"));
  $("actRecv").addEventListener("click", openReceive);
  $("recvList").addEventListener("click", (e) => { const b = e.target.closest("[data-copy]"); if (b) navigator.clipboard?.writeText(b.dataset.copy).then(() => toast("Address copied")); });
  document.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", () => setTab(b.dataset.go)));
  ["connectBtn", "connectBtn2"].forEach((id) => $(id).addEventListener("click", openWalletModal));
  $("fromTokBtn").addEventListener("click", () => openTokModal("from"));
  $("toTokBtn").addEventListener("click", () => openTokModal("to"));
  $("fromAmount").addEventListener("input", (e) => {
    e.target.value = e.target.value.replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1");
    renderQuote(); renderAction(); scheduleQuote();
  });
  $("maxBtn").addEventListener("click", () => {
    if (S.fromBalRaw == null) return;
    let v = S.fromBalRaw;
    if (isNative(S.from.token)) { const keep = chainType(S.from.chainId) === "SVM" ? 10_000_000n : parseUnits("0.002", 18) * (S.from.chainId === 1 ? 5n : 1n); v = v > keep ? v - keep : 0n; }
    $("fromAmount").value = formatUnits(v, S.from.token.decimals); renderQuote(); scheduleQuote(50);
  });
  $("flipBtn").addEventListener("click", () => { [S.from, S.to] = [S.to, S.from]; renderLegs(); refreshLegBalances(); scheduleQuote(50); });
  $("refreshBtn").addEventListener("click", () => getQuote());
  $("settingsBtn").addEventListener("click", () => $("slipBox").classList.toggle("hidden"));
  $("slipBox").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-slip]"); if (!b) return;
    S.slippage = Number(b.dataset.slip); $("slipCustom").value = "";
    document.querySelectorAll("[data-slip]").forEach((x) => x.classList.toggle("on", x === b)); scheduleQuote(50);
  });
  $("slipCustom").addEventListener("input", (e) => {
    const v = Number(e.target.value); if (v > 0 && v <= 50) { S.slippage = v / 100; document.querySelectorAll("[data-slip]").forEach((x) => x.classList.remove("on")); scheduleQuote(); }
  });
  $("actionBtn").addEventListener("click", (e) => e.currentTarget.dataset.mode === "buy" ? buyNxt() : (!addrFor(S.from.chainId) || !addrFor(S.to.chainId)) ? openWalletModal() : execute());
  $("gateBox").addEventListener("click", (e) => { const b = e.target.closest("[data-gate]"); if (!b) return; b.dataset.gate === "buy" ? buyNxt() : checkAccess(); });
  document.querySelectorAll(".modal").forEach((m) => m.addEventListener("click", (e) => { if (e.target === m || e.target.closest("[data-close]")) closeModals(); }));
  document.addEventListener("keydown", (e) => e.key === "Escape" && closeModals());
  $("chainGrid").addEventListener("click", (e) => { const b = e.target.closest("button[data-chain]"); if (!b) return; S.pickChain = Number(b.dataset.chain); renderChainGrid(); renderTokList(); });
  let sT; $("tokSearch").addEventListener("input", () => { clearTimeout(sT); sT = setTimeout(renderTokList, 200); });
  $("tokList").addEventListener("click", (e) => {
    const b = e.target.closest(".tok-row"); if (!b) return;
    const i = b.dataset.i; const list = S.tokens.get(Number(S.pickChain)) || [];
    pickToken(i.startsWith("x") ? $("tokList")._extra[Number(i.slice(1))] : list[Number(i)]);
  });
  $("walEvm").addEventListener("click", (e) => { const b = e.target.closest("[data-evm]"); if (b) connectEvm(b.dataset.evm); });
  $("walSol").addEventListener("click", (e) => { const b = e.target.closest("[data-sol]"); if (b) connectSol(b.dataset.sol); });
  $("wAccounts").addEventListener("click", (e) => {
    const b = e.target.closest("[data-disc]"); if (!b) return;
    if (b.dataset.disc === "sol") { S.sol?.provider.disconnect?.(); S.sol = null; } else S.evm = null;
    onWalletChange();
  });
  $("refreshPort").addEventListener("click", loadPortfolio);
  $("clearAct").addEventListener("click", () => { saveAct([]); renderActivity(); });
  $("netChip").addEventListener("click", () => openTokModal("from"));
}

/* ---------- boot ---------- */
async function boot() {
  bind(); discoverEvm(); setTab("home");
  try {
    await loadChains();
    if (!S.chainById.has(S.from.chainId)) S.from.chainId = S.chains[0].id;
    if (!S.chainById.has(S.to.chainId)) S.to.chainId = S.from.chainId;
    [S.from.token, S.to.token] = await Promise.all([defaultTokens(S.from.chainId, false), defaultTokens(S.to.chainId, true)]);
  } catch (e) { toast("Couldn't reach the routing API: " + e.message, true, 10000); }
  setTab("home"); renderConnect(); renderActivity(); resumeTracking();
  // silently restore previously-trusted Phantom Solana session
  try { const ph = window.phantom?.solana; if (ph?.isPhantom) { const r = await ph.connect({ onlyIfTrusted: true }); S.sol = { key: "phantom", name: "Phantom", icon: solIcon("phantom", "https://phantom.com/favicon.ico"), provider: ph, address: r.publicKey.toString() }; onWalletChange(); } } catch {}
}
boot();
})();
