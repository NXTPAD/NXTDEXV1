# NXT DEX

Multichain swap + bridge wallet home (Phantom-style) for NXT Cloud.
Plain HTML/CSS/JS with no build step. Deploys to Cloudflare Pages from GitHub as-is.

## Access model: hold NXT, trade with no platform fee
- NXT DEX charges **no fee** of its own.
- Swapping and bridging unlock only for wallets holding **any amount of NXT** (more than `NXT_MIN_BALANCE`, default 0).
- Wallets without NXT can still connect, see their balances, and **buy NXT on the site**. That single trade is always allowed, and access unlocks automatically once the purchase lands.
- The balance is re-checked on every connect, account switch, and right before each swap.

## Explore tab
- **Trending**, **New launches**, **Top volume** and **Gainers** across Ethereum, Base, Solana, Arbitrum, BNB Chain, Polygon, Optimism and Avalanche, or one chain at a time.
- Filters: name/symbol/address search, % change window (5m/1h/6h/24h), minimum liquidity, minimum 24h volume, coin age, and sort (volume, % change, liquidity, market cap, newest).
- Coins are flagged **NEW** (under 24h old) and **LOW LIQ** (under $10K liquidity).
- **Trade** loads the coin straight into Swap (the NXT holder gate still applies).
- Data comes from GeckoTerminal's free API (no key; about 10 requests/min per visitor, cached 90s). For heavier traffic, add a CoinGecko API key in `config.js`.

## Setup
1. Open `config.js`.
2. In `NXT_TOKENS`, paste your NXT contract address and chain (and decimals). If NXT lives on several chains, add one line per chain. Holding it on any of them counts.
3. Optionally get a free API key at portal.li.fi for higher rate limits (no fee setup needed).
4. Swap `SOLANA_RPC` for a free Helius/QuickNode/Alchemy URL if you use Solana.

Until a real NXT address is filled in, the site stays locked and shows "NXT token not set up yet".

## Important: what the gate does and doesn't do
The holder check runs in the user's browser. It controls access to **your site**, which is the product experience. It can't stop someone technical from editing the page or calling the routing API (LI.FI) directly, because swaps settle on public DEXs that anyone can use. Treat it as a membership perk, not a security wall. If you later want it enforced server-side (e.g. a Cloudflare Worker that checks a wallet signature + NXT balance before handing out quotes with your private API key), that can be added on top.

Also note: the DEXs and bridges in each route still charge their normal pool/bridge fees and network gas. "No fee" means NXT DEX adds nothing. LI.FI may apply its own service fee depending on your plan, so check portal.li.fi before advertising "zero fees".

## Deploy (GitHub → Cloudflare Pages)
1. Put these files at the root of a GitHub repo.
2. Cloudflare → Workers & Pages → Create → Pages → Connect to Git → pick the repo.
3. Build command: *(none)*. Output directory: `/`. Deploy.
4. Optional: add your logo as `logo.png` next to `index.html`.

## Files
- `index.html`: layout (sidebar, home, swap, activity, sheets)
- `styles.css`: black / baby-blue theme
- `config.js`: **the only file you edit**
- `app.js`: wallets, NXT gate, quotes, swaps, balances, activity
