/* ============================================================
   NXT DEX — the only file you need to edit.
   ============================================================

   ACCESS: HOLD NXT
   ----------------
   Swapping and bridging are free, but only for wallets that hold
   some NXT (any amount above zero). Anyone can still buy NXT
   on the site, so new users have a way in.

   Paste your NXT token contract(s) below. If NXT exists on more
   than one chain, list each one. Holding it on ANY of them unlocks access.
*/
window.NXT_CONFIG = {
  // --- NXT holder gate ------------------------------------------------
  NXT_TOKENS: [
    // EVM example (Base):
    { chainId: 8453, address: "PASTE_NXT_TOKEN_CONTRACT_ON_BASE", decimals: 18 },
    // Solana example (the mint address):
    // { chainId: 1151111081099710, address: "PASTE_NXT_MINT_ADDRESS", decimals: 9 },
  ],
  NXT_SYMBOL: "NXT",
  NXT_LOGO: "assets/logos/nxt.svg", // swap for your NXT coin logo (e.g. "logo.png")
  NXT_MIN_BALANCE: "0",            // must hold MORE than this (in whole tokens). "0" = any amount.

  // --- Routing (LI.FI) ------------------------------------------------
  INTEGRATOR: "nxtdex",            // identifies your site to LI.FI (no fee is charged)
  LIFI_API_KEY: "",                // optional, from portal.li.fi (higher rate limits)

  // --- Explore tab market data (GeckoTerminal) ------------------------
  // Works with no key (about 10 requests/min per visitor, cached).
  // If you buy a CoinGecko API plan, set these for higher limits:
  //   GECKO_BASE: "https://pro-api.coingecko.com/api/v3/onchain", GECKO_API_KEY: "your-key"
  GECKO_BASE: "https://api.geckoterminal.com/api/v2",
  GECKO_API_KEY: "",

  // --- Defaults ------------------------------------------------------
  DEFAULT_SLIPPAGE: 0.005,         // 0.5%
  DEFAULT_FROM_CHAIN: 8453,        // Base
  DEFAULT_TO_CHAIN: 8453,
  // Solana RPC for balance reads. The public one rate-limits hard;
  // a free Helius / QuickNode / Alchemy URL works much better.
  SOLANA_RPC: "https://api.mainnet-beta.solana.com",

  // Chains shown in the wallet token list (IDs). Solana is added automatically.
  PORTFOLIO_CHAINS: [1, 8453, 42161, 10, 137, 56, 43114],
};
