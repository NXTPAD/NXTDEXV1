/* NXT DEX service worker
 * Safe for a live trading app:
 *  - Page loads: network first, cached copy only when offline.
 *  - Static files on your own domain (JS, CSS, images, fonts): served fast from cache, refreshed in the background.
 *  - Anything on another domain (RPC nodes, price APIs, WalletConnect, explorers) is NEVER touched or cached,
 *    so prices, balances and quotes are always live.
 * Bump VERSION every time you deploy a change to this file.
 */
const VERSION = 'nxtdex-v1';
const STATIC_CACHE = `${VERSION}-static`;
const PAGE_CACHE = `${VERSION}-pages`;
const PRECACHE = [
  '/offline.html',
  '/manifest.webmanifest',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(STATIC_CACHE).then((c) => c.addAll(PRECACHE)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Only handle GET requests on this site. Everything else goes straight to the network.
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;

  // Never cache API routes or anything that looks like live data.
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/rpc')) return;

  // Page navigations: network first, fall back to cache, then the offline page.
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(PAGE_CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(async () => (await caches.match(req)) || caches.match('/offline.html'))
    );
    return;
  }

  // Static assets: stale-while-revalidate.
  if (/\.(?:js|css|png|jpg|jpeg|svg|webp|gif|ico|woff2?|ttf)$/.test(url.pathname)) {
    event.respondWith(
      caches.open(STATIC_CACHE).then(async (cache) => {
        const cached = await cache.match(req);
        const network = fetch(req)
          .then((res) => {
            if (res.ok) cache.put(req, res.clone());
            return res;
          })
          .catch(() => cached);
        return cached || network;
      })
    );
  }
});

// Lets the page tell a waiting worker to take over right away (used by the "Update available" prompt).
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
