# NXT DEX: PWA setup

Turns the NXT DEX site into an installable app on iPhone, Android and desktop.

## 1. Copy these into your site's root folder (next to index.html)

```
manifest.webmanifest
sw.js
pwa.js
offline.html
_headers          ← if you already have one, merge the rules instead of replacing it
icons/            ← whole folder
```

If your project uses a build tool (Vite, Next, etc.), put them in the `public/` folder so they end up at the site root.

## 2. Paste the contents of `head-snippet.html` inside `<head>` in index.html

Remove any old `viewport` or `theme-color` tags so they aren't duplicated.

## 3. Commit, push, and let Cloudflare Pages deploy

The site must be on HTTPS (Cloudflare Pages already is).

## 4. Test it

- **Android (Chrome):** open the site. An "Install NXT DEX" bar appears; tap Install.
- **iPhone (Safari):** open the site, tap Share, then Add to Home Screen. The app opens full screen with no browser bar.
- **Desktop Chrome:** open DevTools → Application → Manifest. It should show no errors, and an install icon appears in the address bar.

## Updating later

- Change `VERSION` in `sw.js` (e.g. `nxtdex-v2`) whenever you change sw.js. Users see an "Update available → Refresh" bar.
- Normal site deploys are picked up automatically, because pages load network-first.

## Good to know

- Live data is safe: the service worker never caches other domains (RPCs, price APIs, WalletConnect), or `/api/` routes.
- Wallets: in the installed app, use WalletConnect/Reown or wallet deep links (e.g. Phantom's "open in Phantom" link). Browser-extension wallets don't exist on phones. On iPhone, after approving in a wallet app, the user may land in Safari instead of back in the app. That's an Apple limitation. WalletConnect handles it best.
- The install bar is hidden inside wallet in-app browsers, which can't install apps.
- Optional "Get the app" button anywhere on the site: `<button onclick="window.nxtInstall()">Get the app</button>`
- Icons are placeholders (neon "N"). Replace the files in `icons/` with your logo, using the same names and sizes: 192, 512, maskable 512 with extra padding, 180, and 32.
