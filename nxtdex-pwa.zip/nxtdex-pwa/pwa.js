/* NXT DEX: PWA setup
 * - Registers the service worker
 * - Shows an "Install NXT DEX" bar (a one-tap install on Android/desktop Chrome; Share → Add to Home Screen steps on iPhone)
 * - Shows an "Update available" bar when you deploy a new version
 * Load it with: <script src="/pwa.js" defer></script>
 */
(function () {
  const BLUE = '#5cc8ff';
  const DISMISS_KEY = 'nxtdex-install-dismissed';
  const ua = navigator.userAgent;
  const isIOS = /iphone|ipad|ipod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  // Wallet in-app browsers (Phantom, MetaMask, Coinbase, Trust, OKX...) can't install PWAs, so don't nag there.
  const inWalletBrowser = /Phantom|MetaMask|CoinbaseWallet|Trust|OKApp|BitKeep|Bitget|Rainbow/i.test(ua);
  const isIOSSafari = isIOS && /Safari/i.test(ua) && !/CriOS|FxiOS|EdgiOS/i.test(ua);

  function dismissed() { try { return localStorage.getItem(DISMISS_KEY) === '1'; } catch (e) { return false; } }
  function setDismissed() { try { localStorage.setItem(DISMISS_KEY, '1'); } catch (e) {} }

  function bar(html, buttons) {
    const el = document.createElement('div');
    el.setAttribute('role', 'dialog');
    el.style.cssText =
      'position:fixed;left:12px;right:12px;bottom:calc(12px + env(safe-area-inset-bottom));z-index:99999;' +
      'max-width:480px;margin:0 auto;background:#07121a;color:#e6f6ff;border:1px solid rgba(92,200,255,.35);' +
      'border-radius:16px;padding:14px 16px;display:flex;gap:12px;align-items:center;' +
      'box-shadow:0 8px 32px rgba(0,0,0,.6),0 0 24px rgba(92,200,255,.15);font:14px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif';
    el.innerHTML =
      '<img src="/icons/icon-192.png" alt="" style="width:40px;height:40px;border-radius:10px;flex:none">' +
      '<div style="flex:1;min-width:0">' + html + '</div>';
    buttons.forEach(function (b) {
      const btn = document.createElement('button');
      btn.textContent = b.label;
      btn.style.cssText = b.primary
        ? 'flex:none;background:' + BLUE + ';color:#000;border:0;border-radius:999px;padding:8px 14px;font-weight:700;cursor:pointer'
        : 'flex:none;background:none;color:#8fb8cc;border:0;padding:8px 4px;font-size:18px;cursor:pointer';
      btn.onclick = function () { b.onClick(el); };
      el.appendChild(btn);
    });
    document.body.appendChild(el);
    return el;
  }

  // --- Service worker + update prompt ---
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('/sw.js').then(function (reg) {
        function promptUpdate(worker) {
          bar('<b>Update available</b><br><span style="color:#8fb8cc">A new version of NXT DEX is ready.</span>', [
            { label: 'Refresh', primary: true, onClick: function () { worker.postMessage('SKIP_WAITING'); } }
          ]);
        }
        if (reg.waiting && navigator.serviceWorker.controller) promptUpdate(reg.waiting);
        reg.addEventListener('updatefound', function () {
          const nw = reg.installing;
          nw && nw.addEventListener('statechange', function () {
            if (nw.state === 'installed' && navigator.serviceWorker.controller) promptUpdate(nw);
          });
        });
      });
      // Reload only when an existing version is replaced, not on the very first install.
      const hadController = !!navigator.serviceWorker.controller;
      let reloaded = false;
      navigator.serviceWorker.addEventListener('controllerchange', function () {
        if (hadController && !reloaded) { reloaded = true; location.reload(); }
      });
    });
  }

  if (isStandalone || inWalletBrowser || dismissed()) return;

  // --- Android / desktop Chrome / Edge: native install prompt ---
  let deferred = null;
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferred = e;
    bar('<b>Install NXT DEX</b><br><span style="color:#8fb8cc">Add it to your home screen, just like an app.</span>', [
      { label: 'Install', primary: true, onClick: async function (el) {
          el.remove(); deferred.prompt();
          const r = await deferred.userChoice; if (r.outcome !== 'accepted') setDismissed(); deferred = null;
        } },
      { label: '✕', onClick: function (el) { el.remove(); setDismissed(); } }
    ]);
  });

  // --- iPhone / iPad Safari: show manual steps (Apple has no install button) ---
  if (isIOSSafari) {
    window.addEventListener('load', function () {
      setTimeout(function () {
        bar('<b>Install NXT DEX</b><br><span style="color:#8fb8cc">Tap <b style="color:#e6f6ff">Share</b> ' +
          '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="' + BLUE + '" stroke-width="2" style="vertical-align:-2px"><path d="M12 3v12M7 8l5-5 5 5M5 13v7h14v-7"/></svg>' +
          ' then <b style="color:#e6f6ff">Add to Home Screen</b>.</span>', [
          { label: '✕', onClick: function (el) { el.remove(); setDismissed(); } }
        ]);
      }, 2500);
    });
  }

  // Programmatic hook if you want your own "Get the app" button in the nav:
  //   <button onclick="window.nxtInstall()">Get the app</button>
  window.nxtInstall = function () {
    if (deferred) { deferred.prompt(); return; }
    if (isIOS) alert('On iPhone: tap the Share button in Safari, then "Add to Home Screen".');
    else alert('Open your browser menu and choose "Install app" or "Add to Home screen".');
  };
})();
