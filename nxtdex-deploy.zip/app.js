/* NXT DEX — multichain swap + token launchpad front-end (LI.FI routing · no NXT DEX fee · NXT holders only) */
(() => {
"use strict";
const C = window.NXT_CONFIG;
const API = "https://li.quest/v1";
const SOL_ID = 1151111081099710;
const EVM_NATIVE = "0x0000000000000000000000000000000000000000";
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
/* ---------- logos ----------
   Order tried for every coin: bundled logo (known tokens, matched by contract
   address, never by symbol) → logo from the routing API → public logo CDN →
   generated badge (only if a token has no logo anywhere). */
const LOGO_DIR = "assets/logos/";
const LAUNCH_LOGOS = {}; // chain:address -> logo stored on-chain by NXT Launch
const NATIVE_LOGO = { 4663: "eth", 1: "eth", 8453: "eth", 42161: "eth", 10: "eth", 59144: "eth", 324: "eth", 534352: "eth", 81457: "eth", 7777777: "eth", 56: "bnb", 137: "pol", 43114: "avax", 1151111081099710: "sol" };
const CHAIN_LOGO = { 4663: "chain-robinhood", 1: "eth", 8453: "chain-base", 42161: "chain-arbitrum", 10: "chain-optimism", 137: "pol", 56: "bnb", 43114: "avax", 1151111081099710: "sol" };
const TOKEN_LOGO = {
  usdc: ["1:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", "8453:0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", "42161:0xaf88d065e77c8cc2239327c5edb3a432268e5831", "10:0x0b2c639c533813f4aa9d7837caf62653d097ff85", "137:0x3c499c542cef5e3811e1192ce70d8cc03d5c3359", "56:0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d", "43114:0xb97ef9ef8734c71904d8002f8b6bc66dd9c48a6e", "1151111081099710:EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"],
  usdt: ["1:0xdac17f958d2ee523a2206206994597c13d831ec7", "42161:0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9", "56:0x55d398326f99059ff775485246999027b3197955", "137:0xc2132d05d31c914a87c6611c10748aeb04b58e8f", "1151111081099710:Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"],
  weth: ["1:0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2", "8453:0x4200000000000000000000000000000000000006", "10:0x4200000000000000000000000000000000000006", "42161:0x82af49447d8a07e3bd95bd0d56f35241523fbab1"],
  wbtc: ["1:0x2260fac5e5542a773aa44fbcfedf7c193bc2c599"],
  dai: ["1:0x6b175474e89094c44da98b954eedeac495271d0f"],
};
const TOKEN_LOGO_BY_KEY = Object.fromEntries(Object.entries(TOKEN_LOGO).flatMap(([f, keys]) => keys.map((k) => [k.toLowerCase(), f])));
const nxtLogo = () => (window.NXT_CONFIG && window.NXT_CONFIG.NXT_LOGO) || LOGO_DIR + "nxt.svg";
function tokenLogos(t, chainId) {
  if (!t) return [];
  const cid = Number(chainId ?? t.chainId), addr = String(t.address || "").toLowerCase(), out = [];
  const nxt = (window.NXT_CONFIG?.NXT_TOKENS || []).some((n) => Number(n.chainId) === cid && String(n.address).toLowerCase() === addr);
  if (nxt) out.push(nxtLogo());
  const launched = LAUNCH_LOGOS[cid + ":" + addr]; if (launched) out.push(launched);
  if (isNative(t) && NATIVE_LOGO[cid]) out.push(LOGO_DIR + NATIVE_LOGO[cid] + ".png");
  const f = TOKEN_LOGO_BY_KEY[cid + ":" + addr]; if (f) out.push(LOGO_DIR + f + ".png");
  if (t.logoURI) out.push(t.logoURI);
  if (addr && !isNative(t) && cid !== SOL_ID) out.push(`https://assets.smold.app/api/token/${cid}/${t.address}/logo-128.png`);
  return out;
}
function chainLogos(c) { if (!c) return []; const out = []; if (CHAIN_LOGO[c.id]) out.push(LOGO_DIR + CHAIN_LOGO[c.id] + ".png"); if (c.logoURI) out.push(c.logoURI); out.push(`https://assets.smold.app/api/chain/${c.id}/logo-128.png`); return out; }
function badge(label) {
  const t = String(label || "?").replace(/[^A-Za-z0-9]/g, "").slice(0, 4).toUpperCase() || "?";
  let h = 0; for (const ch of t) h = (h * 31 + ch.charCodeAt(0)) % 360;
  return "data:image/svg+xml;utf8," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${h},70%,62%)"/><stop offset="1" stop-color="hsl(${(h + 50) % 360},70%,40%)"/></linearGradient></defs><circle cx="20" cy="20" r="20" fill="url(#g)"/><text x="20" y="${t.length > 3 ? 24 : 25}" font-size="${t.length > 3 ? 10 : t.length > 2 ? 12 : 15}" font-weight="800" text-anchor="middle" fill="#fff" font-family="system-ui,sans-serif">${t}</text></svg>`);
}
window.nxtImgErr = (el) => {
  const alts = JSON.parse(el.dataset.alt || "[]");
  if (alts.length) { el.dataset.alt = JSON.stringify(alts.slice(1)); el.src = alts[0]; }
  else { el.onerror = null; el.src = badge(el.dataset.label); }
};
function img(srcs, cls = "ico", label = "") {
  const list = (Array.isArray(srcs) ? srcs : [srcs]).filter(Boolean);
  const first = list[0] || badge(label);
  return `<img class="${cls}" src="${esc(first)}" data-alt="${esc(JSON.stringify(list.slice(1)))}" data-label="${esc(label)}" onerror="nxtImgErr(this)" alt="" loading="lazy">`;
}
const tokImg = (t, chainId, cls = "ico") => img(tokenLogos(t, chainId), cls, t?.symbol);
const chainImg = (c, cls = "ico") => img(chainLogos(c), cls, c?.name);
const WALLET_ICON = LOGO_DIR + "wallet.svg";

/* ---------- state ---------- */
const S = {
  tab: "home",
  chains: [], chainById: new Map(), tokens: new Map(), // chainId -> token[]
  from: { chainId: C.DEFAULT_FROM_CHAIN, token: null },
  to: { chainId: C.DEFAULT_TO_CHAIN, token: null },
  slippage: C.DEFAULT_SLIPPAGE,
  evm: null,   // {provider, info, address}
  sol: null,   // {provider, name, icon, address}
  evmWallets: new Map(), // rdns -> {info, provider}
  quote: null, quoteErr: "", loading: false, busy: false,
  access: null, nxtBal: 0, gateMsg: "", // NXT holder gate: null = no wallet, "checking", true, false
  fromBalRaw: null,
  picking: null, pickChain: null,
};

/* ---------- utils ---------- */
function parseUnits(str, dec) {
  str = String(str).trim().replace(/,/g, "");
  if (!/^\d*\.?\d*$/.test(str) || str === "" || str === ".") return 0n;
  const [w, f = ""] = str.split(".");
  return BigInt((w || "0") + f.padEnd(dec, "0").slice(0, dec));
}
function formatUnits(v, dec) {
  v = BigInt(v); const neg = v < 0n; if (neg) v = -v;
  const s = v.toString().padStart(dec + 1, "0");
  const w = s.slice(0, s.length - dec), f = s.slice(s.length - dec).replace(/0+$/, "");
  return (neg ? "-" : "") + w + (f ? "." + f : "");
}
function fmt(n, max = 6) {
  n = Number(n); if (!isFinite(n)) return "—";
  if (n === 0) return "0";
  if (Math.abs(n) < 1e-6) return "<0.000001";
  return n.toLocaleString("en-US", { maximumFractionDigits: n >= 1000 ? 2 : n >= 1 ? 4 : max });
}
const usd = (n) => "$" + (Number(n) || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const short = (a) => a ? a.slice(0, 5) + "…" + a.slice(-4) : "";
const hex = (n) => "0x" + BigInt(n).toString(16);
const isNative = (t) => t && (t.address === EVM_NATIVE || t.address === "11111111111111111111111111111111" || t.address === "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
const chainType = (id) => (S.chainById.get(Number(id)) || {}).chainType;
const addrFor = (id) => chainType(id) === "SVM" ? S.sol?.address : S.evm?.address;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function toast(msg, err = false, ms = 4500) {
  const t = $("toast"); t.textContent = msg; t.className = "toast" + (err ? " err" : "");
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add("hidden"), ms);
}
async function api(path, params) {
  const url = new URL(API + path);
  if (params) Object.entries(params).forEach(([k, v]) => v !== undefined && v !== null && v !== "" && url.searchParams.set(k, v));
  const headers = C.LIFI_API_KEY ? { "x-lifi-api-key": C.LIFI_API_KEY } : {};
  const r = await fetch(url, { headers });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || `Request failed (${r.status})`);
  return j;
}
async function rpc(url, method, params) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
  const j = await r.json(); if (j.error) throw new Error(j.error.message); return j.result;
}
const evmRpcUrl = (id) => (S.chainById.get(Number(id))?.metamask?.rpcUrls || [])[0];
const pad32 = (h) => h.replace(/^0x/, "").toLowerCase().padStart(64, "0");

/* ---------- balances ---------- */
async function evmBalance(chainId, token, owner) {
  const url = evmRpcUrl(chainId); if (!url || !owner) return null;
  if (isNative(token)) return BigInt(await rpc(url, "eth_getBalance", [owner, "latest"]));
  const data = "0x70a08231" + pad32(owner);
  const res = await rpc(url, "eth_call", [{ to: token.address, data }, "latest"]);
  return BigInt(res && res !== "0x" ? res : 0);
}
async function solBalance(token, owner) {
  if (!owner) return null;
  if (isNative(token)) return BigInt((await rpc(C.SOLANA_RPC, "getBalance", [owner])).value);
  const res = await rpc(C.SOLANA_RPC, "getTokenAccountsByOwner", [owner, { mint: token.address }, { encoding: "jsonParsed" }]);
  return res.value.reduce((a, acc) => a + BigInt(acc.account.data.parsed.info.tokenAmount.amount), 0n);
}
async function balanceOf(chainId, token) {
  const owner = addrFor(chainId); if (!owner || !token) return null;
  try { return chainType(chainId) === "SVM" ? await solBalance(token, owner) : await evmBalance(chainId, token, owner); }
  catch { return null; }
}
async function refreshLegBalances() {
  const [fb, tb] = await Promise.all([balanceOf(S.from.chainId, S.from.token), balanceOf(S.to.chainId, S.to.token)]);
  S.fromBalRaw = fb;
  $("fromBal").textContent = fb == null ? "" : "Balance " + fmt(formatUnits(fb, S.from.token.decimals));
  $("toBal").textContent = tb == null ? "" : "Balance " + fmt(formatUnits(tb, S.to.token.decimals));
  renderAction();
}

/* ---------- data loading ---------- */
async function loadChains() {
  const j = await api("/chains", { chainTypes: "EVM,SVM" });
  S.chains = j.chains.sort((a, b) => (a.id === SOL_ID ? -1 : 0) || a.name.localeCompare(b.name));
  const pri = [1, 8453, SOL_ID, 42161, 56, 137, 10, 43114];
  S.chains.sort((a, b) => ((pri.indexOf(a.id) + 1 || 99) - (pri.indexOf(b.id) + 1 || 99)) || a.name.localeCompare(b.name));
  S.chains.forEach((c) => S.chainById.set(c.id, c));
  $("netCount").textContent = S.chains.length + " chains";
  $("searchBtn").querySelector("span").textContent = `Search tokens on ${S.chains.length} chains`;
}
async function tokensFor(chainId) {
  chainId = Number(chainId);
  if (S.tokens.has(chainId)) return S.tokens.get(chainId);
  const j = await api("/tokens", { chains: chainId, chainTypes: "EVM,SVM" });
  const list = (j.tokens[chainId] || []).sort((a, b) => (isNative(b) - isNative(a)) || (Number(b.priceUSD || 0) > 0) - (Number(a.priceUSD || 0) > 0));
  S.tokens.set(chainId, list); return list;
}
async function defaultTokens(chainId, preferStable) {
  const list = await tokensFor(chainId);
  const native = list.find(isNative) || list[0];
  const stable = list.find((t) => t.symbol === "USDC") || list.find((t) => t.symbol === "USDT") || list[1];
  return preferStable ? stable : native;
}

/* ---------- render ---------- */
function renderLegs() {
  for (const side of ["from", "to"]) {
    const leg = S[side], c = S.chainById.get(Number(leg.chainId)), t = leg.token;
    $(side + "TokBtn").innerHTML = t ? `<span class="ico-wrap">${tokImg(t, leg.chainId)}${c ? chainImg(c, "sub") : ""}</span><span>${esc(t.symbol)}</span>` : "<span>Select</span>";
    $(side + "ChainTag").textContent = c ? "on " + c.name : "";
  }
  $("swapTitle").textContent = S.from.chainId !== S.to.chainId ? "Swap across chains" : "Swap";
}
function renderQuote() {
  const q = S.quote, box = $("quoteBox");
  const amt = Number($("fromAmount").value || 0);
  $("fromUsd").textContent = usd(amt * Number(S.from.token?.priceUSD || 0));
  if (!q) { box.classList.add("hidden"); $("toAmount").value = ""; $("toUsd").textContent = "$0.00"; return; }
  const e = q.estimate, ft = q.action.fromToken, tt = q.action.toToken;
  const out = Number(formatUnits(e.toAmount, tt.decimals));
  const inn = Number(formatUnits(q.action.fromAmount, ft.decimals));
  $("toAmount").value = fmt(out);
  $("toUsd").textContent = usd(e.toAmountUSD || out * Number(tt.priceUSD || 0));
  $("qRate").textContent = `1 ${ft.symbol} ≈ ${fmt(out / inn)} ${tt.symbol}`;
  const gas = (e.gasCosts || []).reduce((a, g) => a + Number(g.amountUSD || 0), 0);
  $("qGas").textContent = gas ? usd(gas) : "—";
  $("qMin").textContent = `${fmt(formatUnits(e.toAmountMin, tt.decimals))} ${tt.symbol}`;
  const steps = (q.includedSteps || []).map((s) => s.toolDetails?.name || s.tool).filter(Boolean);
  $("qRoute").textContent = steps.length ? [...new Set(steps)].join(" → ") : (q.toolDetails?.name || q.tool);
  $("qTime").textContent = e.executionDuration ? (e.executionDuration < 60 ? `~${e.executionDuration}s` : `~${Math.round(e.executionDuration / 60)} min`) : "—";
  box.classList.remove("hidden");
}
function renderAction() {
  const b = $("actionBtn"); b.disabled = false;
  const need = chainType(S.from.chainId) === "SVM" ? "Solana" : "EVM";
  const amt = $("fromAmount").value;
  if (S.busy) { b.textContent = S.busy; b.disabled = true; return; }
  if (!addrFor(S.from.chainId)) { b.textContent = `Connect ${need} Wallet`; return; }
  if (!addrFor(S.to.chainId)) { b.textContent = `Connect ${chainType(S.to.chainId) === "SVM" ? "Solana" : "EVM"} wallet to receive`; return; }
  b.dataset.mode = "";
  if (S.access === "checking") { b.textContent = `Checking ${C.NXT_SYMBOL} balance…`; b.disabled = true; return; }
  if (!canTrade()) { b.textContent = S.gateMsg && !nxtList().length ? S.gateMsg : `Hold ${C.NXT_SYMBOL} to unlock · Buy ${C.NXT_SYMBOL}`; b.dataset.mode = "buy"; b.disabled = !nxtList().length; return; }
  if (!S.from.token || !S.to.token) { b.textContent = "Select tokens"; b.disabled = true; return; }
  if (!amt || Number(amt) <= 0) { b.textContent = "Enter an amount"; b.disabled = true; return; }
  if (S.fromBalRaw != null && parseUnits(amt, S.from.token.decimals) > S.fromBalRaw) { b.textContent = `Insufficient ${S.from.token.symbol}`; b.disabled = true; return; }
  if (S.loading) { b.textContent = "Finding best route…"; b.disabled = true; return; }
  if (S.quoteErr) { b.textContent = S.quoteErr.length > 60 ? "No route found" : S.quoteErr; b.disabled = true; return; }
  if (!S.quote) { b.textContent = "Get quote"; return; }
  b.textContent = buyingNxt() && S.access !== true ? `Buy ${C.NXT_SYMBOL}` : S.from.chainId === S.to.chainId ? "Swap" : "Bridge";
}

/* ---------- NXT holder gate ---------- */
const nxtList = () => (C.NXT_TOKENS || []).filter((t) => t.address && !/^PASTE/i.test(t.address));
const isNxt = (chainId, token) => !!token && nxtList().some((n) => Number(n.chainId) === Number(chainId) && n.address.toLowerCase() === String(token.address).toLowerCase());
const buyingNxt = () => isNxt(S.to.chainId, S.to.token);
const canTrade = () => S.access === true || buyingNxt();
let gateSeq = 0;
async function checkAccess() {
  const seq = ++gateSeq;
  if (!S.evm && !S.sol) { S.access = null; S.nxtBal = 0; renderGate(); return null; }
  const list = nxtList();
  if (!list.length) { S.access = false; S.gateMsg = `${C.NXT_SYMBOL} token not set up yet`; renderGate(); return false; }
  S.access = "checking"; S.gateMsg = ""; renderGate();
  let total = 0, checked = 0, failed = 0;
  await Promise.all(list.map(async (n) => {
    const svm = Number(n.chainId) === SOL_ID;
    const owner = svm ? S.sol?.address : S.evm?.address;
    if (!owner) return;
    checked++;
    try {
      const raw = svm ? await solBalance(n, owner) : await evmBalance(n.chainId, n, owner);
      if (raw == null) throw new Error("no rpc");
      total += Number(formatUnits(raw, n.decimals ?? 18));
    } catch { failed++; }
  }));
  if (seq !== gateSeq) return S.access;
  S.nxtBal = total;
  S.access = total > Number(C.NXT_MIN_BALANCE || 0);
  if (!S.access) {
    if (!checked) S.gateMsg = `Connect the ${list.some((n) => Number(n.chainId) === SOL_ID) && !list.some((n) => Number(n.chainId) !== SOL_ID) ? "Solana" : "EVM"} wallet that holds your ${C.NXT_SYMBOL}`;
    else if (failed === checked) S.gateMsg = `Couldn't check your ${C.NXT_SYMBOL} balance — tap Recheck`;
  }
  renderGate(); return S.access;
}
function renderGate() {
  const box = $("gateBox"); const sym = esc(C.NXT_SYMBOL);
  if (S.access === null) box.innerHTML = "";
  else if (S.access === "checking") box.innerHTML = `<div class="gate-pill">Checking ${sym} balance…</div>`;
  else if (S.access === true) box.innerHTML = `<div class="gate-pill ok">✓ ${sym} holder · ${fmt(S.nxtBal)} ${sym} · Swaps unlocked</div>`;
  else box.innerHTML = `<div class="gate-lock"><div class="lock-ico">🔒</div><div class="gate-txt"><b>Hold any amount of ${sym} to unlock</b>
      <small>${esc(S.gateMsg) || `NXT DEX is for ${sym} holders, with no platform fee. Buy a little ${sym} to get in.`}</small></div>
      <div class="gate-btns">${nxtList().length ? `<button class="btn-sm" data-gate="buy">Buy ${sym}</button>` : ""}<button class="btn-sm ghost" data-gate="recheck">Recheck</button></div></div>`;
  $("swapCard").classList.toggle("locked", S.access !== null && !canTrade());
  renderAction(); renderLnButton();
}
async function buyNxt() {
  const list = nxtList(); if (!list.length) return toast(`${C.NXT_SYMBOL} token isn't configured yet`, true);
  const n = list.find((x) => (Number(x.chainId) === SOL_ID ? S.sol : S.evm)) || list[0];
  const chainId = Number(n.chainId);
  let token;
  try { token = await api("/token", { chain: chainId, token: n.address }); }
  catch { token = { chainId, address: n.address, decimals: n.decimals ?? 18, symbol: C.NXT_SYMBOL, name: C.NXT_SYMBOL, logoURI: "", priceUSD: "0" }; }
  S.to = { chainId, token };
  S.from = { chainId, token: await defaultTokens(chainId, false) };
  setTab("swap"); refreshLegBalances(); scheduleQuote(50);
  toast(`Buy any amount of ${C.NXT_SYMBOL} to unlock NXT DEX`);
}
function renderConnect() {
  const any = S.evm || S.sol;
  const b = $("connectBtn");
  b.innerHTML = any ? `<span class="avatar"></span><span><code>${esc(short(S.evm?.address || S.sol?.address))}</code>${S.evm && S.sol ? ' <small class="muted">+1</small>' : ""}</span>` : "Connect";
  b.classList.toggle("on", !!any);
  $("wEmpty").classList.toggle("hidden", !!any);
  $("wFull").classList.toggle("hidden", !any);
  $("wAccounts").innerHTML = [
    S.evm && `<div class="acct">${img([S.evm.info.icon, WALLET_ICON], "ico", S.evm.info.name)}<span>${esc(S.evm.info.name)}</span><code>${short(S.evm.address)}</code><button class="x" data-disc="evm" title="Disconnect">✕</button></div>`,
    S.sol && `<div class="acct">${img([S.sol.icon, WALLET_ICON], "ico", S.sol.name)}<span>${esc(S.sol.name)} · Solana</span><code>${short(S.sol.address)}</code><button class="x" data-disc="sol" title="Disconnect">✕</button></div>`,
  ].filter(Boolean).join("");
  renderAction();
}

/* ---------- quote ---------- */
let qTimer, qSeq = 0;
function scheduleQuote(delay = 550) { clearTimeout(qTimer); qTimer = setTimeout(getQuote, delay); }
async function getQuote() {
  const seq = ++qSeq, amtStr = $("fromAmount").value;
  S.quote = null; S.quoteErr = "";
  const ft = S.from.token, tt = S.to.token;
  const amount = ft ? parseUnits(amtStr, ft.decimals) : 0n;
  if (!ft || !tt || amount <= 0n) { S.loading = false; renderQuote(); renderAction(); return; }
  if (S.from.chainId === S.to.chainId && ft.address === tt.address) { S.quoteErr = "Pick two different tokens"; renderQuote(); renderAction(); return; }
  S.loading = true; renderQuote(); renderAction();
  const fromAddr = addrFor(S.from.chainId) || (chainType(S.from.chainId) === "SVM" ? "DDmSXv1rnU7W2vJBoAy7GzUJ7hpsEBzmBJyY5RTa7Zhx" : "0x552008c0f6870c2f77e5cC1d2eb9bdff03e30Ea0"); // placeholder address used only to preview a price before connecting
  try {
    const q = await api("/quote", {
      fromChain: S.from.chainId, toChain: S.to.chainId, fromToken: ft.address, toToken: tt.address,
      fromAmount: amount.toString(), fromAddress: fromAddr, toAddress: addrFor(S.to.chainId) || undefined,
      slippage: S.slippage, integrator: C.INTEGRATOR, order: "CHEAPEST",
    });
    if (seq !== qSeq) return;
    S.quote = q;
  } catch (e) { if (seq !== qSeq) return; S.quoteErr = e.message || "No route found"; }
  S.loading = false; renderQuote(); renderAction();
}
setInterval(() => { if (S.quote && !S.busy && document.visibilityState === "visible") getQuote(); }, 30000);

/* ---------- EVM wallets (EIP-6963 + legacy) ---------- */
window.addEventListener("eip6963:announceProvider", (e) => {
  const { info, provider } = e.detail; S.evmWallets.set(info.rdns || info.uuid, { info, provider }); renderWalletList();
});
function discoverEvm() {
  window.dispatchEvent(new Event("eip6963:requestProvider"));
  setTimeout(() => {
    if (!S.evmWallets.size && window.ethereum) S.evmWallets.set("injected", { info: { name: window.ethereum.isCoinbaseWallet ? "Base Wallet" : window.ethereum.isPhantom ? "Phantom" : "Browser Wallet", icon: "" }, provider: window.ethereum });
    renderWalletList();
  }, 250);
}
async function connectEvm(key) {
  const w = S.evmWallets.get(key); if (!w) return;
  try {
    const [address] = await w.provider.request({ method: "eth_requestAccounts" });
    S.evm = { ...w, address };
    w.provider.on?.("accountsChanged", (a) => { if (!a.length) S.evm = null; else S.evm.address = a[0]; onWalletChange(); });
    toast(`Connected ${w.info.name}`); closeModals(); onWalletChange();
  } catch (e) { toast(e.message || "Connection rejected", true); }
}
async function ensureEvmChain(chainId) {
  const p = S.evm.provider, want = hex(chainId);
  const cur = await p.request({ method: "eth_chainId" });
  if (BigInt(cur) === BigInt(chainId)) return;
  try { await p.request({ method: "wallet_switchEthereumChain", params: [{ chainId: want }] }); }
  catch (e) {
    if (e.code !== 4902 && e?.data?.originalError?.code !== 4902) throw e;
    const m = S.chainById.get(Number(chainId)).metamask;
    await p.request({ method: "wallet_addEthereumChain", params: [{ ...m, chainId: want }] });
  }
}
async function waitReceipt(hash) {
  for (let i = 0; i < 180; i++) {
    const r = await S.evm.provider.request({ method: "eth_getTransactionReceipt", params: [hash] }).catch(() => null);
    if (r) { if (r.status === "0x0") throw new Error("Transaction reverted"); return r; }
    await sleep(2000);
  }
  throw new Error("Timed out waiting for confirmation");
}

/* ---------- Solana wallets ---------- */
// Real wallet icons via the Wallet Standard (Phantom, Solflare, Backpack all register one)
const stdIcons = {};
const stdRegister = (...ws) => { ws.forEach((w) => { if (w?.name && w.icon) stdIcons[w.name.toLowerCase()] = w.icon; }); return () => {}; };
window.addEventListener("wallet-standard:register-wallet", (e) => { try { e.detail({ register: stdRegister }); } catch {} });
try { window.dispatchEvent(new CustomEvent("wallet-standard:app-ready", { detail: { register: stdRegister } })); } catch {}
const solIcon = (key, fallback) => stdIcons[key] || fallback;
function solWallets() {
  const list = [];
  const ph = window.phantom?.solana; if (ph?.isPhantom) list.push({ key: "phantom", name: "Phantom", icon: solIcon("phantom", "https://phantom.com/favicon.ico"), provider: ph });
  if (window.solflare?.isSolflare) list.push({ key: "solflare", name: "Solflare", icon: solIcon("solflare", "https://solflare.com/favicon.ico"), provider: window.solflare });
  if (window.backpack?.solana) list.push({ key: "backpack", name: "Backpack", icon: solIcon("backpack", "https://backpack.app/favicon.ico"), provider: window.backpack.solana });
  return list;
}
async function connectSol(key) {
  const w = solWallets().find((x) => x.key === key); if (!w) return;
  try {
    const res = await w.provider.connect();
    const pk = res?.publicKey || w.provider.publicKey;
    S.sol = { ...w, address: pk.toString() };
    w.provider.on?.("accountChanged", (pk2) => { if (pk2) S.sol.address = pk2.toString(); else S.sol = null; onWalletChange(); });
    toast(`Connected ${w.name}`); closeModals(); onWalletChange();
  } catch (e) { toast(e.message || "Connection rejected", true); }
}
function b64ToBytes(b64) { return Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)); }

function renderWalletList() {
  const evm = [...S.evmWallets.entries()];
  $("walEvm").innerHTML = evm.length ? evm.map(([k, w]) =>
    `<button class="wal" data-evm="${esc(k)}">${img([w.info.icon, WALLET_ICON], "ico", w.info.name)}${esc(w.info.name)}${S.evm?.info.name === w.info.name ? '<span class="tag">Connected</span>' : ""}</button>`).join("")
    : `<p class="muted small">No EVM wallet found. Install MetaMask, Phantom, Rabby or Base Wallet.</p>`;
  const sol = solWallets();
  $("walSol").innerHTML = sol.length ? sol.map((w) =>
    `<button class="wal" data-sol="${w.key}">${img([w.icon, WALLET_ICON], "ico", w.name)}${esc(w.name)}${S.sol?.key === w.key ? '<span class="tag">Connected</span>' : ""}</button>`).join("")
    : `<p class="muted small">No Solana wallet found. Install <a href="https://phantom.com" target="_blank" rel="noopener">Phantom</a>.</p>`;
}
function onWalletChange() { renderConnect(); checkAccess(); refreshLegBalances(); scheduleQuote(100); loadPortfolio(); }

/* ---------- execute swap ---------- */
async function execute() {
  if (!addrFor(S.from.chainId) || !addrFor(S.to.chainId)) return openWalletModal();
  if (!canTrade()) return buyNxt();
  if (!buyingNxt() && (await checkAccess()) !== true) return toast(`You need to hold ${C.NXT_SYMBOL} to swap`, true);
  if (!S.quote) return getQuote();
  const q = S.quote, ft = q.action.fromToken;
  const setBusy = (t) => { S.busy = t; renderAction(); };
  try {
    let hash;
    if (chainType(S.from.chainId) === "SVM") {
      setBusy("Confirm in wallet…");
      const tx = window.solanaWeb3.VersionedTransaction.deserialize(b64ToBytes(q.transactionRequest.data));
      const res = await S.sol.provider.signAndSendTransaction(tx);
      hash = res.signature || res;
    } else {
      setBusy("Switching network…");
      await ensureEvmChain(S.from.chainId);
      const from = S.evm.address, amount = BigInt(q.action.fromAmount);
      if (!isNative(ft) && q.estimate.approvalAddress) {
        const allowance = BigInt(await rpc(evmRpcUrl(S.from.chainId), "eth_call", [{ to: ft.address, data: "0xdd62ed3e" + pad32(from) + pad32(q.estimate.approvalAddress) }, "latest"]) || 0);
        if (allowance < amount) {
          setBusy(`Approve ${ft.symbol} in wallet…`);
          const ah = await S.evm.provider.request({ method: "eth_sendTransaction", params: [{ from, to: ft.address, data: "0x095ea7b3" + pad32(q.estimate.approvalAddress) + pad32(hex(amount)) }] });
          setBusy("Waiting for approval…");
          await waitReceipt(ah);
          await getQuote(); // refresh calldata after approval
          if (!S.quote) throw new Error(S.quoteErr || "Quote expired");
        }
      }
      const tr = S.quote.transactionRequest;
      setBusy("Confirm swap in wallet…");
      hash = await S.evm.provider.request({ method: "eth_sendTransaction", params: [{ from, to: tr.to, data: tr.data, value: tr.value || "0x0", ...(tr.gasLimit ? { gas: tr.gasLimit } : {}) }] });
    }
    const item = {
      hash, time: Date.now(), fromChain: S.from.chainId, toChain: S.to.chainId, bridge: S.quote.tool,
      fromSym: ft.symbol, fromTok: { address: ft.address, symbol: ft.symbol, logoURI: ft.logoURI }, toSym: S.quote.action.toToken.symbol,
      fromAmt: formatUnits(S.quote.action.fromAmount, ft.decimals), toAmt: formatUnits(S.quote.estimate.toAmount, S.quote.action.toToken.decimals),
      status: "PENDING",
    };
    addActivity(item); toast("Transaction submitted ✓");
    $("fromAmount").value = ""; S.quote = null; renderQuote();
    trackStatus(item);
    if (isNxt(item.toChain, S.to.token)) setTimeout(checkAccess, 15000);
  } catch (e) {
    toast(e?.message?.includes("rejected") || e?.code === 4001 ? "Transaction cancelled" : (e.message || "Swap failed"), true);
  } finally { S.busy = false; renderAction(); refreshLegBalances(); }
}

/* ---------- activity ---------- */
const ACT_KEY = "nxtdex_activity";
function loadAct() { try { return JSON.parse(localStorage.getItem(ACT_KEY) || "[]"); } catch { return []; } }
function saveAct(a) { try { localStorage.setItem(ACT_KEY, JSON.stringify(a.slice(0, 100))); } catch {} }
function addActivity(item) { const a = loadAct(); a.unshift(item); saveAct(a); renderActivity(); }
function updateActivity(hash, patch) { const a = loadAct(); const i = a.findIndex((x) => x.hash === hash); if (i >= 0) { Object.assign(a[i], patch); saveAct(a); renderActivity(); } }
function explorer(chainId, hash) {
  if (Number(chainId) === SOL_ID) return `https://solscan.io/tx/${hash}`;
  const b = (S.chainById.get(Number(chainId))?.metamask?.blockExplorerUrls || [])[0];
  return b ? b.replace(/\/$/, "") + "/tx/" + hash : `https://scan.li.fi/tx/${hash}`;
}
function renderActivity() {
  const a = loadAct();
  $("actList").innerHTML = a.length ? a.map((x) => {
    const fc = S.chainById.get(Number(x.fromChain)), tc = S.chainById.get(Number(x.toChain));
    return `<div class="act"><span class="ico-wrap">${x.fromTok ? tokImg(x.fromTok, x.fromChain) : chainImg(fc)}${x.fromTok ? chainImg(fc, "sub") : ""}</span><div><b>${fmt(x.fromAmt)} ${esc(x.fromSym)} → ${fmt(x.toAmt)} ${esc(x.toSym)}</b><br>
      <small class="muted">${esc(fc?.name || "")}${x.fromChain !== x.toChain ? " → " + esc(tc?.name || "") : ""} · ${new Date(x.time).toLocaleString()} · <a href="${esc(explorer(x.fromChain, x.hash))}" target="_blank" rel="noopener">View</a></small></div>
      <span class="st ${esc(x.status)}">${esc(x.status)}</span></div>`;
  }).join("") : `<p class="muted">No swaps yet.</p>`;
}
async function trackStatus(item) {
  for (let i = 0; i < 240; i++) {
    await sleep(i < 10 ? 4000 : 10000);
    try {
      const s = await api("/status", { txHash: item.hash, fromChain: item.fromChain, toChain: item.toChain, bridge: item.fromChain !== item.toChain ? item.bridge : undefined });
      if (s.status === "DONE" || s.status === "FAILED") {
        updateActivity(item.hash, { status: s.status });
        toast(s.status === "DONE" ? `${item.fromSym} → ${item.toSym} complete ✓` : "Swap failed — funds stay in your wallet or are refunded", s.status === "FAILED");
        refreshLegBalances(); loadPortfolio(); checkAccess(); return;
      }
    } catch {}
  }
}
function resumeTracking() { loadAct().filter((x) => x.status === "PENDING" && Date.now() - x.time < 864e5).forEach(trackStatus); }

/* ---------- portfolio ---------- */
let portSeq = 0;
async function loadPortfolio() {
  const seq = ++portSeq;
  if (!S.evm && !S.sol) { $("wList").innerHTML = `<p class="muted pad">Connect a wallet to see your tokens.</p>`; $("holdCount").textContent = ""; return; }
  $("wList").innerHTML = `<p class="muted">Loading balances…</p>`;
  const jobs = [];
  const watch = (sym) => ["USDC", "USDT", "WETH", "WBTC", "DAI", "cbBTC"].includes(sym);
  if (S.evm) for (const id of C.PORTFOLIO_CHAINS) {
    if (!S.chainById.has(id)) continue;
    jobs.push(tokensFor(id).then((list) => Promise.all(list.filter((t) => (isNative(t) || watch(t.symbol)) && !isNxt(id, t)).slice(0, 6).concat(list.filter((t) => isNxt(id, t)))
      .map(async (t) => ({ t, c: S.chainById.get(id), raw: await evmBalance(id, t, S.evm.address).catch(() => null) })))).catch(() => []));
  }
  if (S.sol && S.chainById.has(SOL_ID)) jobs.push(tokensFor(SOL_ID).then((list) => Promise.all(list.filter((t) => isNative(t) || ["USDC", "USDT"].includes(t.symbol)).slice(0, 3)
    .map(async (t) => ({ t, c: S.chainById.get(SOL_ID), raw: await solBalance(t, S.sol.address).catch(() => null) })))).catch(() => []));
  for (const n of nxtList()) {
    const svm = Number(n.chainId) === SOL_ID, owner = svm ? S.sol?.address : S.evm?.address;
    if (!owner || !S.chainById.has(Number(n.chainId))) continue;
    jobs.push(tokensFor(n.chainId).catch(() => []).then(async (list) => {
      if (list.some((t) => String(t.address).toLowerCase() === n.address.toLowerCase())) return []; // already covered below
      let t = { chainId: Number(n.chainId), address: n.address, decimals: n.decimals ?? 18, symbol: C.NXT_SYMBOL, name: C.NXT_SYMBOL, priceUSD: "0" };
      try { t = await api("/token", { chain: n.chainId, token: n.address }); } catch {}
      return [{ t, c: S.chainById.get(Number(n.chainId)), raw: await (svm ? solBalance(t, owner) : evmBalance(n.chainId, t, owner)).catch(() => null) }];
    }));
  }
  const rows = (await Promise.all(jobs)).flat().filter((r) => r.raw && r.raw > 0n)
    .map((r) => { const amt = Number(formatUnits(r.raw, r.t.decimals)); return { ...r, amt, val: amt * Number(r.t.priceUSD || 0) }; })
    .sort((a, b) => b.val - a.val);
  if (seq !== portSeq) return;
  const total = rows.reduce((a, r) => a + r.val, 0);
  $("wTotal").textContent = usd(total);
  $("holdCount").textContent = rows.length ? rows.length + " assets" : "";
  $("wSub").textContent = (() => { const n = new Set(rows.map((r) => r.c.id)).size; return `across ${n} chain${n === 1 ? "" : "s"}`; })();
  const html = rows.length ? rows.map((r) => `<div class="hold"><span class="ico-wrap">${tokImg(r.t, r.c.id)}${chainImg(r.c, "sub")}</span><div class="nm"><b>${esc(r.t.symbol)}</b><small>${esc(r.c.name)}</small></div>
    <div class="vl"><b>${usd(r.val)}</b><small>${fmt(r.amt)} ${esc(r.t.symbol)}</small></div></div>`).join("")
    : `<p class="muted pad">No balances found on the tracked chains.</p>`;
  $("wList").innerHTML = html;
}

/* ---------- token modal ---------- */
async function openTokModal(side) {
  S.picking = side; S.pickChain = S[side].chainId;
  $("tokModal").classList.remove("hidden"); $("tokSearch").value = ""; renderChainGrid(); await renderTokList();
  $("tokSearch").focus();
}
function renderChainGrid() {
  $("chainGrid").innerHTML = S.chains.map((c) => `<button data-chain="${c.id}" class="${c.id === Number(S.pickChain) ? "on" : ""}">${chainImg(c, "")}${esc(c.name)}</button>`).join("");
}
async function renderTokList() {
  const box = $("tokList"); box.innerHTML = `<p class="muted">Loading tokens…</p>`;
  let list; try { list = await tokensFor(S.pickChain); } catch (e) { box.innerHTML = `<p class="muted">Couldn't load tokens: ${esc(e.message)}</p>`; return; }
  const q = $("tokSearch").value.trim().toLowerCase();
  let res = q ? list.filter((t) => t.symbol.toLowerCase().includes(q) || (t.name || "").toLowerCase().includes(q) || t.address.toLowerCase() === q) : list;
  if (!res.length && q.length > 30) {
    try { const t = await api("/token", { chain: S.pickChain, token: $("tokSearch").value.trim() }); res = [t]; } catch {}
  }
  box.innerHTML = res.slice(0, 250).map((t, i) => `<button class="tok-row" data-i="${list.indexOf(t) >= 0 ? list.indexOf(t) : "x" + i}"><span class="ico-wrap">${tokImg(t, S.pickChain)}</span><div><b>${esc(t.symbol)}</b><small>${esc(t.name)}</small></div><span class="px">${Number(t.priceUSD) ? usd(t.priceUSD) : ""}</span></button>`).join("")
    || `<p class="muted">No tokens match. Paste a contract address to import.</p>`;
  box._extra = res;
}
async function pickToken(t) {
  const side = S.picking; S[side].chainId = Number(S.pickChain); S[side].token = t;
  closeModals(); renderLegs(); refreshLegBalances(); scheduleQuote(50); renderAction();
}

/* ---------- modals / tabs ---------- */
function closeModals() { document.querySelectorAll(".modal").forEach((m) => m.classList.add("hidden")); }
function openWalletModal() { discoverEvm(); renderWalletList(); $("walModal").classList.remove("hidden"); }
function setTab(tab) {
  S.tab = tab;
  document.querySelectorAll("[data-nav] button").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  $("view-home").classList.toggle("hidden", tab !== "home");
  $("view-swap").classList.toggle("hidden", tab !== "swap");
  $("view-activity").classList.toggle("hidden", tab !== "activity");
  $("view-explore").classList.toggle("hidden", tab !== "explore");
  $("view-launch").classList.toggle("hidden", tab !== "launch");
  (tab === "home" ? $("slotHome") : $("slotSwap")).appendChild($("swapCard"));
  if (tab === "activity") renderActivity();
  if (tab === "explore") loadExplore();
  if (tab === "launch") openLaunch();
  if (tab === "home") loadPortfolio();
  renderLegs(); window.scrollTo({ top: 0 });
}
function openReceive() {
  const rows = [
    S.evm && { n: "EVM address", s: "Ethereum, Base, Arbitrum, BNB, Polygon + all EVM chains", a: S.evm.address },
    S.sol && { n: "Solana address", s: "SOL and SPL tokens", a: S.sol.address },
  ].filter(Boolean);
  $("recvList").innerHTML = rows.length ? rows.map((r) => `<div class="recv"><span class="avatar"></span><div><b>${r.n}</b><small class="muted">${r.s}</small><br><code>${esc(r.a)}</code></div>
    <button class="icon-btn" data-copy="${esc(r.a)}" title="Copy"><svg><use href="#i-copy"/></svg></button></div>`).join("") : `<p class="muted">Connect a wallet first.</p>`;
  $("recvModal").classList.remove("hidden");
}

/* ---------- explore (GeckoTerminal market data) ---------- */
const GT = (C.GECKO_BASE || "https://api.geckoterminal.com/api/v2");
const GT_NET = { eth: 1, base: 8453, solana: SOL_ID, arbitrum: 42161, bsc: 56, polygon_pos: 137, optimism: 10, avax: 43114 };
const GT_BY_CHAIN = Object.fromEntries(Object.entries(GT_NET).map(([k, v]) => [v, k]));
const GT_NAMES = { eth: "Ethereum", base: "Base", solana: "Solana", arbitrum: "Arbitrum", bsc: "BNB Chain", polygon_pos: "Polygon", optimism: "Optimism", avax: "Avalanche" };
const EX = { tab: "trending", net: "all", tf: "h24", page: 1, rows: [], loading: false, err: "", loadedKey: "" };
const gtCache = new Map();
async function gt(path, params = {}) {
  const url = new URL(GT + path);
  Object.entries(params).forEach(([k, v]) => v != null && url.searchParams.set(k, v));
  const key = url.toString(), hit = gtCache.get(key);
  if (hit && Date.now() - hit.t < 90_000) return hit.data; // stay under the free ~10 calls/min limit
  const headers = { accept: "application/json;version=20230302" };
  if (C.GECKO_API_KEY) headers["x-cg-pro-api-key"] = C.GECKO_API_KEY;
  const r = await fetch(key, { headers });
  if (r.status === 429) throw new Error("Market data is busy. Retrying in a minute.");
  if (!r.ok) throw new Error(`Market data unavailable (${r.status})`);
  const data = await r.json(); gtCache.set(key, { t: Date.now(), data }); return data;
}
function parsePools(json) {
  const inc = new Map((json.included || []).map((x) => [x.id, x]));
  return (json.data || []).map((p) => {
    const a = p.attributes || {}, bt = p.relationships?.base_token?.data?.id || "";
    const net = p.relationships?.network?.data?.id || bt.slice(0, bt.lastIndexOf("_"));
    const tok = inc.get(bt)?.attributes || {};
    const address = tok.address || bt.slice(bt.lastIndexOf("_") + 1);
    const ch = a.price_change_percentage || {};
    const tx = a.transactions?.h24 || {};
    return {
      key: net + ":" + address.toLowerCase(), net, chainId: GT_NET[net], address,
      symbol: tok.symbol || String(a.name || "").split(" / ")[0], name: tok.name || a.name || "",
      image: tok.image_url && !/missing/i.test(tok.image_url) ? tok.image_url : "",
      price: Number(a.base_token_price_usd) || 0,
      ch: { m5: +ch.m5 || 0, h1: +ch.h1 || 0, h6: +ch.h6 || 0, h24: +ch.h24 || 0 },
      vol: Number(a.volume_usd?.h24) || 0, liq: Number(a.reserve_in_usd) || 0,
      mcap: Number(a.market_cap_usd) || Number(a.fdv_usd) || 0,
      created: Date.parse(a.pool_created_at) || 0, buys: tx.buys || 0, sells: tx.sells || 0,
    };
  }).filter((r) => r.chainId); // only chains NXT DEX can trade
}
function exEndpoint(page) {
  const all = EX.net === "all", inc = { include: "base_token", page };
  if (EX.tab === "new") return [all ? "/networks/new_pools" : `/networks/${EX.net}/new_pools`, inc];
  if (EX.tab === "top" && !all) return [`/networks/${EX.net}/pools`, { ...inc, sort: "h24_volume_usd_desc" }];
  return [all ? "/networks/trending_pools" : `/networks/${EX.net}/trending_pools`, inc];
}
async function loadExplore(more = false) {
  const key = EX.tab + "|" + EX.net;
  if (!more && EX.loadedKey === key && EX.rows.length) return renderExplore();
  EX.page = more ? EX.page + 1 : 1; EX.loading = true; EX.err = "";
  if (!more) EX.rows = [];
  renderExplore();
  try {
    const [path, params] = exEndpoint(EX.page);
    const rows = parsePools(await gt(path, params));
    const seen = new Map(EX.rows.map((r) => [r.key, r]));
    rows.forEach((r, i) => { r.rank = EX.rows.length + i + 1; const prev = seen.get(r.key); if (!prev || r.liq > prev.liq) seen.set(r.key, prev ? { ...r, rank: prev.rank } : r); });
    EX.rows = [...seen.values()]; EX.loadedKey = key;
    if (!rows.length && more) EX.page--;
  } catch (e) { EX.err = e.message; if (more) EX.page--; }
  EX.loading = false; renderExplore();
}
const money = (n) => !n ? "—" : n >= 1e9 ? "$" + (n / 1e9).toFixed(2) + "B" : n >= 1e6 ? "$" + (n / 1e6).toFixed(2) + "M" : n >= 1e3 ? "$" + (n / 1e3).toFixed(1) + "K" : "$" + n.toFixed(0);
function price(n) {
  if (!n) return "—";
  if (n >= 1) return "$" + n.toLocaleString("en-US", { maximumFractionDigits: n >= 1000 ? 0 : 2 });
  if (n >= 0.0001) return "$" + n.toPrecision(3);
  const e = Math.floor(-Math.log10(n)) - 1; // leading zeros after "0."
  return `$0.0<sub>${e}</sub>${Math.round(n * 10 ** (e + 4))}`;
}
function age(t) {
  if (!t) return "—"; const s = (Date.now() - t) / 1000;
  return s < 3600 ? Math.max(1, Math.round(s / 60)) + "m" : s < 86400 ? Math.round(s / 3600) + "h" : s < 86400 * 60 ? Math.round(s / 86400) + "d" : s < 86400 * 365 ? Math.round(s / 86400 / 30) + "mo" : (s / 86400 / 365).toFixed(1).replace(/\.0$/, "") + "y";
}
function exFiltered() {
  const q = $("exSearch").value.trim().toLowerCase();
  const minLiq = +$("exLiq").value, minVol = +$("exVol").value, ageLim = +$("exAge").value, sort = $("exSort").value, tf = EX.tf;
  let rows = EX.rows.filter((r) =>
    (!q || r.symbol.toLowerCase().includes(q) || r.name.toLowerCase().includes(q) || r.address.toLowerCase() === q) &&
    r.liq >= minLiq && r.vol >= minVol &&
    (!ageLim || (ageLim > 0 ? Date.now() - r.created <= ageLim * 1000 : Date.now() - r.created >= -ageLim * 1000)));
  const by = { vol: (a, b) => b.vol - a.vol, chg: (a, b) => b.ch[tf] - a.ch[tf], liq: (a, b) => b.liq - a.liq, mcap: (a, b) => b.mcap - a.mcap, age: (a, b) => b.created - a.created };
  if (sort !== "default") rows.sort(by[sort]);
  else if (EX.tab === "gainers") rows.sort(by.chg);
  else if (EX.tab === "top") rows.sort(by.vol);
  else if (EX.tab === "new") rows.sort(by.age);
  else rows.sort((a, b) => a.rank - b.rank);
  return rows;
}
function renderExChains() {
  const nets = ["all", ...Object.keys(GT_NET)];
  $("exChains").innerHTML = nets.map((n) => {
    const c = n === "all" ? null : (S.chainById.get(GT_NET[n]) || { id: GT_NET[n], name: GT_NAMES[n] });
    return `<button data-net="${n}" class="${EX.net === n ? "on" : ""}">${c ? chainImg(c, "") : '<svg><use href="#i-explore"/></svg>'}${n === "all" ? "All chains" : esc(GT_NAMES[n])}</button>`;
  }).join("");
}
function renderExplore() {
  renderExChains();
  document.querySelectorAll("#exTabs [data-ex]").forEach((b) => b.classList.toggle("on", b.dataset.ex === EX.tab));
  document.querySelectorAll("#exTf [data-tf]").forEach((b) => b.classList.toggle("on", b.dataset.tf === EX.tf));
  $("exChgHead").textContent = { m5: "5m", h1: "1h", h6: "6h", h24: "24h" }[EX.tf];
  const box = $("exList");
  if (EX.loading && !EX.rows.length) { box.innerHTML = Array.from({ length: 8 }, () => '<div class="ex-row sk"><span></span><span></span><span></span><span></span></div>').join(""); }
  else if (EX.err && !EX.rows.length) box.innerHTML = `<p class="muted pad">${esc(EX.err)} <button class="btn-sm ghost" data-exretry>Retry</button></p>`;
  else {
    const rows = exFiltered();
    box.innerHTML = rows.length ? rows.map((r, i) => {
      const c = S.chainById.get(r.chainId) || { id: r.chainId, name: GT_NAMES[r.net] };
      const chg = r.ch[EX.tf], isNew = r.created && Date.now() - r.created < 86400e3;
      const risky = r.liq < 10000;
      return `<div class="ex-row" data-key="${esc(r.key)}">
        <span class="ex-rank">${i + 1}</span>
        <span class="ex-coin"><span class="ico-wrap">${tokImg({ address: r.address, symbol: r.symbol, logoURI: r.image }, r.chainId)}${chainImg(c, "sub")}</span>
          <span class="ex-nm"><b>${esc(r.symbol)}${isNew ? '<em class="tag new">NEW</em>' : ""}${risky ? '<em class="tag risk">LOW LIQ</em>' : ""}</b><small>${esc(r.name)} · ${esc(c.name)}</small></span></span>
        <span class="r ex-price">${price(r.price)}</span>
        <span class="r ex-chg ${chg >= 0 ? "up" : "down"}">${chg >= 0 ? "+" : ""}${chg.toFixed(Math.abs(chg) >= 100 ? 0 : 2)}%</span>
        <span class="r ex-vol" data-l="Vol">${money(r.vol)}</span>
        <span class="r ex-liq" data-l="Liq">${money(r.liq)}</span>
        <span class="r ex-mc" data-l="MC">${money(r.mcap)}</span>
        <span class="r ex-age" data-l="Age">${age(r.created)}</span>
        <span class="ex-meta">Vol ${money(r.vol)} · Liq ${money(r.liq)} · ${age(r.created)}</span>
        <span class="r ex-trade"><button class="btn-sm" data-trade="${esc(r.key)}">Trade</button></span>
      </div>`;
    }).join("") : `<p class="muted pad">No coins match these filters. Try lowering the liquidity or volume minimum.</p>`;
  }
  $("exMore").classList.toggle("hidden", !EX.rows.length || EX.page >= 10);
  $("exMore").textContent = EX.loading && EX.rows.length ? "Loading…" : "Load more";
  $("exMeta").textContent = EX.err && EX.rows.length ? EX.err : EX.rows.length ? `${exFiltered().length} of ${EX.rows.length} coins shown` : "";
}
async function tradeCoin(key) {
  const r = EX.rows.find((x) => x.key === key); if (!r) return;
  let token;
  try { token = await api("/token", { chain: r.chainId, token: r.address }); }
  catch { return toast(`${r.symbol} isn't routable on NXT DEX yet (no liquidity found by the router)`, true); }
  if (!token.logoURI && r.image) token.logoURI = r.image;
  S.to = { chainId: r.chainId, token };
  S.from = { chainId: r.chainId, token: await defaultTokens(r.chainId, false) };
  if (isNative(S.from.token) && isNative(token)) S.from.token = await defaultTokens(r.chainId, true);
  $("fromAmount").value = "";
  setTab("swap"); refreshLegBalances(); renderQuote(); renderAction();
  toast(`${token.symbol} on ${S.chainById.get(r.chainId)?.name || GT_NAMES[r.net]} loaded into Swap`);
}
setInterval(() => { if (S.tab === "explore" && document.visibilityState === "visible" && !EX.loading) { EX.loadedKey = ""; gtCache.clear(); loadExplore(); } }, 120_000);

/* ---------- launchpad (NXT Launch factory + Uniswap V2) ---------- */
const LC = C.LAUNCH || { CHAINS: [] };
const DEAD = "0x000000000000000000000000000000000000dEaD";
const SEL = {
  createToken: "115c0d18", launchFee: "cf3cf573", allTokensLength: "dbb80e42", setLaunchFee: "5313be2c",
  approve: "095ea7b3", transfer: "a9059cbb", balanceOf: "70a08231", totalSupply: "18160ddd",
  openTrading: "ca72a4e7", renounceOwnership: "715018a6", owner: "8da5cb5b", pair: "a8aa1b31", tradingOpen: "ffb54a99",
  launchedAtBlock: "05e30932", allTokens: "634282af", addLiquidityETH: "f305d719", swapETH: "b6f9de95", factory: "c45a0155", WETH: "ad5c4648", getPair: "e6a43905",
};
const TOPIC_LAUNCHED = "0x97e6433900650dc1353be10d2e8c02660b7fa0a79be2f03abbafeefa45588bd7";
const LN = { chainId: null, logo: "", snipe: 10, maxW: 100, feeWei: null, floorWei: null, price: null, scope: "chain", running: null, recentSeq: 0 };

/* --- tiny ABI encoder / decoder --- */
const w64 = (h) => h.replace(/^0x/, "").padStart(64, "0");
const encUint = (v) => BigInt(v).toString(16).padStart(64, "0");
const encAddr = (a) => w64(String(a).toLowerCase());
const utf8hex = (str) => [...new TextEncoder().encode(str)].map((b) => b.toString(16).padStart(2, "0")).join("");
function encodeArgs(types, values) {
  const headLen = 32 * types.length; const head = []; const tail = []; let tailLen = 0;
  types.forEach((t, i) => {
    const v = values[i];
    if (t === "string" || t === "address[]") {
      const chunk = t === "string"
        ? (() => { const hx = utf8hex(v); return encUint(hx.length / 2) + hx.padEnd(Math.ceil(hx.length / 64) * 64, "0"); })()
        : encUint(v.length) + v.map(encAddr).join("");
      head.push(encUint(headLen + tailLen)); tail.push(chunk); tailLen += chunk.length / 2;
    } else if (t === "address") head.push(encAddr(v));
    else if (t === "bool") head.push(encUint(v ? 1 : 0));
    else head.push(encUint(v));
  });
  return head.join("") + tail.join("");
}
const cdata = (sel, types = [], vals = []) => "0x" + sel + encodeArgs(types, vals);
const word = (hex, i) => hex.replace(/^0x/, "").slice(i * 64, i * 64 + 64);
const decAddr = (hex, i = 0) => "0x" + word(hex, i).slice(24);
const decUint = (hex, i = 0) => BigInt("0x" + (word(hex, i) || "0"));
function decString(hex, i) {
  const h = hex.replace(/^0x/, ""); const off = Number(BigInt("0x" + word(h, i))) * 2;
  const len = Number(BigInt("0x" + h.slice(off, off + 64))) * 2;
  const bytes = h.slice(off + 64, off + 64 + len).match(/../g) || [];
  return new TextDecoder().decode(new Uint8Array(bytes.map((b) => parseInt(b, 16))));
}

/* --- chain helpers --- */
const isAdmin = () => /admin/i.test(location.hash);
const hasRpc = (c) => /^https?:\/\//.test(c.rpc || "");
// Users only see chains that are fully working: factory deployed + RPC configured. Admin sees all with an RPC.
const launchChains = () => (LC.CHAINS || []).filter((c) => !c.testnet && hasRpc(c) && (isAdmin() || hasFactory(c)));
const lchain = (id = LN.chainId) => launchChains().find((c) => c.chainId === Number(id));
function hasFactory(c) { return !!c && /^0x[0-9a-fA-F]{40}$/.test(c.factory || ""); }
async function walletOn(chainId) {
  if (!S.evm) return false;
  try { return BigInt(await S.evm.provider.request({ method: "eth_chainId" })) === BigInt(chainId); } catch { return false; }
}
async function lread(c, method, params) {
  if (c.rpc) return rpc(c.rpc, method, params);
  if (await walletOn(c.chainId)) return S.evm.provider.request({ method, params });
  throw new Error(`Add an RPC for ${c.name} in config.js`);
}
async function lbatch(c, calls) { // JSON-RPC batch of eth_calls → array of results (null on error)
  if (!calls.length) return [];
  if (!c.rpc) return Promise.all(calls.map((x) => lread(c, "eth_call", [x, "latest"]).catch(() => null)));
  try {
    const r = await fetch(c.rpc, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(calls.map((x, i) => ({ jsonrpc: "2.0", id: i, method: "eth_call", params: [x, "latest"] }))) });
    const j = await r.json(); if (!Array.isArray(j)) throw 0;
    const out = Array(calls.length).fill(null); j.forEach((x) => { if (x && !x.error) out[x.id] = x.result; }); return out;
  } catch { return Promise.all(calls.map((x) => rpc(c.rpc, "eth_call", [x, "latest"]).catch(() => null))); }
}
async function ensureLaunchChain(c) {
  const p = S.evm.provider, want = hex(c.chainId);
  if (await walletOn(c.chainId)) return;
  try { await p.request({ method: "wallet_switchEthereumChain", params: [{ chainId: want }] }); }
  catch (e) {
    if (e.code !== 4902 && e?.data?.originalError?.code !== 4902) throw e;
    const m = S.chainById.get(c.chainId)?.metamask;
    await p.request({ method: "wallet_addEthereumChain", params: [m ? { ...m, chainId: want } : { chainId: want, chainName: c.name, nativeCurrency: { name: c.native, symbol: c.native, decimals: 18 }, rpcUrls: [c.rpc].filter(Boolean), blockExplorerUrls: [c.explorer] }] });
  }
}
async function sendTx(tx) {
  return S.evm.provider.request({ method: "eth_sendTransaction", params: [{ from: S.evm.address, ...tx, value: tx.value ? hex(tx.value) : "0x0" }] });
}
const walletCall = (to, data) => S.evm.provider.request({ method: "eth_call", params: [{ to, data }, "latest"] });
const natPrice = async (chainId) => {
  const c = (LC.CHAINS || []).find((x) => x.chainId === Number(chainId)); const pc = c?.priceChain || chainId;
  try { const t = (await tokensFor(pc)).find(isNative); return Number(t?.priceUSD) || null; } catch { return null; }
};

/* --- form + preview --- */
const lnNum = (id) => Number(String($(id).value).replace(/[, _]/g, "")) || 0;
function lnParams() {
  const supply = Math.floor(lnNum("lnSupply")), liq = lnNum("lnLiq"), buy = lnNum("lnBuy"), alloc = Number($("lnAlloc").value);
  const lpTokens = supply * (1 - alloc / 100);
  return {
    name: $("lnName").value.trim(), symbol: $("lnSym").value.trim().toUpperCase(), desc: $("lnDesc").value.trim(),
    web: $("lnWeb").value.trim(), x: $("lnX").value.trim(), tg: $("lnTg").value.trim(), dc: $("lnDc").value.trim(),
    supply, liq, buy, alloc, lpTokens, snipe: LN.snipe, maxW: LN.maxW,
    burn: $("lnBurn").checked, renounce: $("lnRenounce").checked, logo: LN.logo || $("lnLogoUrl").value.trim(),
  };
}
function lnMeta(p) {
  const m = { i: p.logo || undefined, d: p.desc || undefined, w: p.web || undefined, x: p.x || undefined, t: p.tg || undefined, c: p.dc || undefined, v: 1 };
  return JSON.stringify(m);
}
const fmtNat = (wei, sym) => wei == null ? "—" : `${fmt(formatUnits(wei, 18), 6)} ${sym}`;
function renderLnChains() {
  $("lnChains").innerHTML = launchChains().map((c) => {
    const ch = S.chainById.get(c.chainId) || { id: c.chainId, name: c.name };
    return `<button data-lchain="${c.chainId}" class="${c.chainId === LN.chainId ? "on" : ""}">${chainImg(ch, "")}${esc(c.name)}${hasFactory(c) ? "" : "<em>Needs factory</em>"}</button>`;
  }).join("");
}
function renderLnPreview() {
  const c = lchain(); if (!c) return;
  const p = lnParams(), nat = c.native;
  document.querySelectorAll(".lnNat").forEach((e) => (e.textContent = nat));
  $("lnAllocV").textContent = p.alloc + "%";
  const pv = $("lnPvLogo"); const logos = p.logo ? [p.logo] : [LOGO_DIR + "nxt.svg"];
  if (pv.dataset.src !== logos[0]) { pv.dataset.src = logos[0]; pv.src = logos[0]; }
  const chImg = chainLogos(S.chainById.get(c.chainId) || { id: c.chainId, name: c.name });
  $("lnPvChain").src = chImg[0] || badge(c.name);
  $("lnPvName").textContent = p.name || "Your coin";
  $("lnPvSym").textContent = `${p.symbol || "TICKER"} · ${c.name}`;
  const priceNat = p.lpTokens > 0 && p.liq > 0 ? p.liq / p.lpTokens : 0;
  const usdP = LN.price ? priceNat * LN.price : null;
  const small = (n) => n >= 0.01 ? "$" + n.toFixed(4) : price(n);
  $("lnPvPrice").innerHTML = priceNat ? (usdP != null ? small(usdP) : `${priceNat.toPrecision(3)} ${nat}`) : "—";
  $("lnPvMcap").textContent = priceNat ? (usdP != null ? money(usdP * p.supply) : `${fmt(priceNat * p.supply, 4)} ${nat}`) : "—";
  $("lnPvPool").textContent = p.liq && p.lpTokens ? `${fmt(p.liq, 6)} ${nat} + ${fmt(p.lpTokens, 0)} ${p.symbol || "tokens"}` : "—";
  $("lnPvAlloc").textContent = p.alloc ? `${fmt(p.supply * p.alloc / 100, 0)} (${p.alloc}%)` : "None";
  if (p.buy > 0 && p.liq > 0) {
    const out = (p.lpTokens * p.buy * 0.997) / (p.liq + p.buy * 0.997);
    $("lnPvBuy").textContent = `${Math.round(out).toLocaleString("en-US")} (${((out / p.supply) * 100).toFixed(2)}%)`;
  } else $("lnPvBuy").textContent = "None";
  const feeWei = LN.feeWei;
  $("lnPvFee").textContent = feeWei == null ? (hasFactory(c) ? "Loading…" : "—") : `$${Number(LC.FEE_USD || 1).toFixed(2)} · ${fmtNat(feeWei, nat)}`;
  $("lnFeePill").textContent = `$${Number(LC.FEE_USD || 1).toFixed(0)} launch fee in ${nat}`;
  const spend = parseUnits(String(p.liq || 0), 18) + parseUnits(String(p.buy || 0), 18);
  $("lnPvSpend").textContent = fmtNat(spend, nat) + (LN.price ? ` (${usd(Number(formatUnits(spend, 18)) * LN.price)})` : "");
  const total = spend + (feeWei || 0n);
  $("lnPvTotal").textContent = fmtNat(total, nat) + (LN.price ? ` (${usd(Number(formatUnits(total, 18)) * LN.price)})` : "");
  renderLnButton();
}
function lnProblem(p) {
  if (!p.name) return "Add a name";
  if (!p.symbol) return "Add a ticker";
  if (!/^[A-Z0-9$._-]{1,12}$/.test(p.symbol)) return "Ticker: letters & numbers only";
  if (!(p.supply >= 1000 && p.supply <= 1e15)) return "Supply must be 1,000 – 1,000,000,000,000,000";
  if (!(p.liq > 0)) return "Add liquidity";
  if (p.buy < 0) return "Early buy can't be negative";
  if (p.buy > p.liq * 3) return "Early buy is larger than 3× the pool";
  if (new TextEncoder().encode(lnMeta(p)).length > 12000) return "Logo too large. Try a smaller image";
  return "";
}
function renderLnButton() {
  const b = $("lnGo"), c = lchain(), p = lnParams(); b.disabled = false; b.dataset.mode = "";
  if (!S.evm) { b.textContent = "Connect wallet"; b.dataset.mode = "connect"; return; }
  if (S.access === "checking") { b.textContent = `Checking ${C.NXT_SYMBOL} balance…`; b.disabled = true; return; }
  if (S.access !== true) { b.textContent = `Hold ${C.NXT_SYMBOL} to launch · Buy ${C.NXT_SYMBOL}`; b.dataset.mode = "buy"; b.disabled = !nxtList().length; return; }
  if (!hasFactory(c)) { b.textContent = `Launchpad not set up on ${c ? c.name : "this chain"} yet`; b.disabled = true; return; }
  const prob = lnProblem(p); if (prob) { b.textContent = prob; b.disabled = true; return; }
  if (LN.running) { b.textContent = "Launch in progress…"; b.dataset.mode = "show"; return; }
  b.textContent = `Launch $${p.symbol} on ${c.name}`; b.dataset.mode = "go";
}
async function selectLaunchChain(id) {
  LN.chainId = Number(id); LN.feeWei = null; LN.price = null;
  renderLnChains(); renderLnPreview();
  const c = lchain(), seq = ++LN.recentSeq;
  $("lnChainHint").innerHTML = hasFactory(c) ? `Liquidity goes to Uniswap V2 on ${esc(c.name)}. The coin is tradable the moment you open trading.` : `The launchpad isn't set up on ${esc(c.name)} yet. The site owner deploys it once from <b>#admin</b>.`;
  const [price] = await Promise.all([natPrice(c.chainId)]);
  if (seq !== LN.recentSeq) return;
  LN.price = price;
  if (hasFactory(c)) {
    try {
      const floor = BigInt(await lread(c, "eth_call", [{ to: c.factory, data: "0x" + SEL.launchFee }, "latest"]));
      const want = price ? parseUnits(((LC.FEE_USD || 1) / price).toFixed(18), 18) : floor;
      LN.floorWei = floor; LN.feeWei = want > floor ? want : floor;
    } catch { LN.feeWei = null; }
  }
  if (seq === LN.recentSeq) { renderLnPreview(); loadLaunchRecent(); }
}
function openLaunch() {
  const none = !launchChains().length;
  $("lnEmpty").classList.toggle("hidden", !none);
  document.querySelectorAll(".ln-grid, .ln-recent-head, #lnRecent").forEach((e) => e.classList.toggle("hidden", none));
  $("lnAdmin").classList.toggle("hidden", !isAdmin());
  if (none) return;
  if (LN.chainId && !lchain()) LN.chainId = null;
  if (!LN.chainId) {
    const first = launchChains().find(hasFactory) || launchChains()[0];
    if (first) selectLaunchChain(first.chainId);
  } else { renderLnChains(); renderLnPreview(); loadLaunchRecent(); }
  if (!$("lnAdmTreasury").value && LC.TREASURY && !/^PASTE/.test(LC.TREASURY)) $("lnAdmTreasury").value = LC.TREASURY;
  loadLaunchTotal();
}
async function lnLogoFromFile(file) {
  if (!file || !file.type.startsWith("image/")) return toast("Pick an image file", true);
  const url = URL.createObjectURL(file);
  const im = new Image(); im.src = url; await im.decode().catch(() => null);
  const cv = document.createElement("canvas"); cv.width = cv.height = 96;
  const ctx = cv.getContext("2d"); const s = Math.min(im.width, im.height);
  ctx.drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, 96, 96);
  let data = cv.toDataURL("image/webp", 0.82);
  if (!data.startsWith("data:image/webp")) data = cv.toDataURL("image/jpeg", 0.82);
  URL.revokeObjectURL(url);
  LN.logo = data; $("lnLogoImg").src = data; $("lnLogoImg").classList.remove("hidden"); $("lnLogoPh").classList.add("hidden");
  renderLnPreview();
}

/* --- launch job: resumable, step by step --- */
const LJ_KEY = "nxtdex_launches";
const loadJobs = () => { try { return JSON.parse(localStorage.getItem(LJ_KEY) || "[]"); } catch { return []; } };
const saveJob = (job) => { try { const a = loadJobs().filter((j) => j.id !== job.id); a.unshift(job); localStorage.setItem(LJ_KEY, JSON.stringify(a.slice(0, 50))); } catch {} $("lnMine").textContent = loadJobs().filter((j) => j.token).length; };
function jobSteps(job) {
  const p = job.p, nat = lchain(job.chainId)?.native || "ETH";
  return [
    { k: "create", t: `Create $${p.symbol}`, d: `Deploys the coin and pays the ${fmtNat(BigInt(job.feeWei), nat)} ($${LC.FEE_USD || 1}) launch fee` },
    { k: "approve", t: "Approve liquidity", d: `Lets Uniswap take ${fmt(p.lpTokens, 0)} ${p.symbol} for the pool` },
    { k: "liquidity", t: "Create the pool", d: `Adds ${fmt(p.liq, 6)} ${nat} + ${fmt(p.lpTokens, 0)} ${p.symbol} on Uniswap V2` },
    p.buy > 0 && { k: "buy", t: "Your early buy", d: `Buys with ${fmt(p.buy, 6)} ${nat} before trading opens` },
    { k: "open", t: "Open trading", d: p.snipe ? `Anti-sniper: ${p.snipe} blocks, max ${(p.maxW / 100)}% per wallet` : "Anyone can trade from here" },
    p.burn && { k: "burn", t: "Burn LP tokens", d: "Liquidity locked forever" },
    p.renounce && { k: "renounce", t: "Renounce ownership", d: "No admin keys left" },
  ].filter(Boolean);
}
function renderJob(job) {
  const steps = jobSteps(job), c = lchain(job.chainId);
  const allDone = steps.every((s) => job.done[s.k]);
  $("lnMTitle").textContent = allDone ? `$${job.p.symbol} is live 🎉` : job.error ? "Launch paused" : `Launching $${job.p.symbol}`;
  $("lnMCoin").innerHTML = `<span class="ico-wrap">${img([job.p.logo, LOGO_DIR + "nxt.svg"].filter(Boolean), "ico", job.p.symbol)}${chainImg(S.chainById.get(job.chainId) || { id: job.chainId, name: c?.name }, "sub")}</span>
    <div><b>${esc(job.p.name)}</b><small>$${esc(job.p.symbol)} · ${esc(c?.name || "")}${job.token ? ` · <a href="${esc(c.explorer)}/token/${job.token}" target="_blank" rel="noopener">${short(job.token)}</a>` : ""}</small></div>`;
  let activeSet = false;
  $("lnSteps").innerHTML = steps.map((s) => {
    const done = job.done[s.k]; let st = done ? "done" : "wait";
    if (!done && !activeSet) { st = job.error ? "fail" : job.running ? "run" : "wait"; activeSet = true; }
    const tx = job.tx[s.k] ? ` · <a href="${esc(c.explorer)}/tx/${job.tx[s.k]}" target="_blank" rel="noopener">tx</a>` : "";
    return `<li class="${st}"><i>${st === "done" ? '<svg><use href="#i-check"/></svg>' : st === "run" ? '<span class="spin"></span>' : st === "fail" ? "!" : ""}</i><div><b>${esc(s.t)}</b><small>${st === "fail" ? esc(job.error) : esc(s.d)}${tx}</small></div></li>`;
  }).join("");
  const shareText = encodeURIComponent(`I just launched $${job.p.symbol} on ${c?.name} with NXT DEX 🚀 LP ${job.p.burn ? "burned" : "added"}, anti-sniper on.`);
  const shareUrl = encodeURIComponent(`${c?.explorer}/token/${job.token}`);
  $("lnMBtns").innerHTML = allDone
    ? `<button class="btn-main" data-lnact="trade">Trade $${esc(job.p.symbol)}</button>
       <div class="ln-share"><a class="btn-sm ghost" target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?text=${shareText}&url=${shareUrl}">Share on X</a>
       <a class="btn-sm ghost" target="_blank" rel="noopener" href="https://t.me/share/url?url=${shareUrl}&text=${shareText}">Telegram</a>
       <button class="btn-sm ghost" data-lnact="copy">Copy address</button></div>`
    : job.error ? `<button class="btn-main" data-lnact="retry">Retry this step</button><p class="fine">Nothing is lost. Your progress is saved, and retrying picks up where it stopped.</p>`
    : `<p class="fine">Confirm each step in your wallet. Keep this window open.</p>`;
}
async function runJob(job) {
  LN.running = job; job.running = true; job.error = ""; renderJob(job); renderLnButton();
  $("lnModal").classList.remove("hidden");
  const c = lchain(job.chainId), p = job.p, me = S.evm.address;
  const wei = (n) => parseUnits(String(n), 18);
  const lpWei = parseUnits(String(Math.floor(p.lpTokens)), 18);
  const step = async (k, fn) => { if (job.done[k]) return; renderJob(job); const h = await fn(); if (h) { job.tx[k] = h; saveJob(job); renderJob(job); await waitReceipt(h); } job.done[k] = true; saveJob(job); renderJob(job); };
  try {
    await ensureLaunchChain(c);
    await step("create", async () => {
      const h = await sendTx({ to: c.factory, data: cdata(SEL.createToken, ["string", "string", "uint256", "uint16", "uint16", "string"], [p.name, p.symbol, Math.floor(p.supply), p.snipe, p.maxW, lnMeta(p)]), value: BigInt(job.feeWei) });
      job.tx.create = h; saveJob(job);
      const rc = await waitReceipt(h);
      const log = (rc.logs || []).find((l) => l.topics?.[0]?.toLowerCase() === TOPIC_LAUNCHED && l.address.toLowerCase() === c.factory.toLowerCase());
      if (!log) throw new Error("Coin created but its address wasn't found in the receipt");
      job.token = "0x" + log.topics[1].slice(26); saveJob(job);
      if (p.logo) LAUNCH_LOGOS[job.chainId + ":" + job.token.toLowerCase()] = p.logo;
    });
    await step("approve", () => sendTx({ to: job.token, data: cdata(SEL.approve, ["address", "uint256"], [c.router, lpWei]) }));
    await step("liquidity", () => sendTx({ to: c.router, value: wei(p.liq), data: cdata(SEL.addLiquidityETH, ["address", "uint256", "uint256", "uint256", "address", "uint256"], [job.token, lpWei, lpWei, wei(p.liq), me, Math.floor(Date.now() / 1000) + 1800]) }));
    if (!job.weth) { job.weth = decAddr(await walletCall(c.router, "0x" + SEL.WETH)); job.uniFactory = decAddr(await walletCall(c.router, "0x" + SEL.factory)); saveJob(job); }
    // amountOutMin 0 is safe here: until trading opens, only the creator can trade this coin.
    if (p.buy > 0) await step("buy", () => sendTx({ to: c.router, value: wei(p.buy), data: cdata(SEL.swapETH, ["uint256", "address[]", "address", "uint256"], [0, [job.weth, job.token], me, Math.floor(Date.now() / 1000) + 1800]) }));
    if (!job.pair) { job.pair = decAddr(await walletCall(job.uniFactory, cdata(SEL.getPair, ["address", "address"], [job.token, job.weth]))); saveJob(job); }
    await step("open", () => sendTx({ to: job.token, data: cdata(SEL.openTrading, ["address"], [job.pair]) }));
    if (p.burn) await step("burn", async () => {
      const lp = decUint(await walletCall(job.pair, cdata(SEL.balanceOf, ["address"], [me])));
      return lp > 0n ? sendTx({ to: job.pair, data: cdata(SEL.transfer, ["address", "uint256"], [DEAD, lp]) }) : null;
    });
    if (p.renounce) await step("renounce", () => sendTx({ to: job.token, data: "0x" + SEL.renounceOwnership }));
    job.running = false; job.finished = Date.now(); saveJob(job); renderJob(job);
    toast(`$${p.symbol} is live on ${c.name}`); loadLaunchRecent(true); loadLaunchTotal(); refreshLegBalances();
  } catch (e) {
    job.running = false;
    job.error = e?.code === 4001 || /reject|denied/i.test(e?.message || "") ? "You cancelled in your wallet." : (e?.message || "Transaction failed").slice(0, 160);
    saveJob(job); renderJob(job);
  } finally { if (!job.error && job.finished) LN.running = null; renderLnButton(); }
}
async function startLaunch() {
  const c = lchain(), p = lnParams();
  if (lnProblem(p) || !hasFactory(c) || S.access !== true) return renderLnButton();
  if ((await checkAccess()) !== true) return toast(`You need to hold ${C.NXT_SYMBOL} to launch`, true);
  if (LN.feeWei == null) return toast("Couldn't load the launch fee. Try again in a moment", true);
  const job = { id: Date.now().toString(36), chainId: c.chainId, p, feeWei: LN.feeWei.toString(), done: {}, tx: {}, created: Date.now() };
  saveJob(job); runJob(job);
}

/* --- recently launched + totals --- */
async function loadLaunchTotal() {
  const cs = launchChains().filter(hasFactory);
  const counts = await Promise.all(cs.map((c) => lread(c, "eth_call", [{ to: c.factory, data: "0x" + SEL.allTokensLength }, "latest"]).then((r) => Number(BigInt(r))).catch(() => 0)));
  $("lnTotal").textContent = cs.length ? counts.reduce((a, b) => a + b, 0).toLocaleString() : "0";
  $("lnMine").textContent = loadJobs().filter((j) => j.token).length;
}
const recentCache = new Map();
async function loadLaunchRecent(force = false) {
  const box = $("lnRecent"), c = lchain(), seq = LN.recentSeq;
  if (LN.scope === "mine") {
    const mine = loadJobs().filter((j) => j.token).map((j) => ({ token: j.token, creator: S.evm?.address || "", name: j.p.name, symbol: j.p.symbol, meta: { i: j.p.logo }, time: (j.finished || j.created) / 1000, chainId: j.chainId, job: j }));
    return renderRecent(mine, "You haven't launched a coin yet.");
  }
  if (!hasFactory(c)) return (box.innerHTML = `<p class="muted pad">Launches on ${esc(c?.name || "this chain")} will show here once the launchpad is set up.</p>`);
  const key = c.chainId;
  if (!force && recentCache.has(key) && Date.now() - recentCache.get(key).t < 60_000) return renderRecent(recentCache.get(key).rows);
  box.innerHTML = '<div class="ln-rc sk"></div>'.repeat(4);
  try {
    // Registry-based: newest 12 tokens from the factory, then one single-block log query each
    // for the metadata. No wide block-range scans, so it works on any public RPC and any chain speed.
    const len = Number(BigInt(await lread(c, "eth_call", [{ to: c.factory, data: "0x" + SEL.allTokensLength }, "latest"])));
    const idx = []; for (let i = len - 1; i >= 0 && idx.length < 12; i--) idx.push(i);
    const addrs = (await lbatch(c, idx.map((i) => ({ to: c.factory, data: cdata(SEL.allTokens, ["uint256"], [i]) })))).map((r) => r && decAddr(r)).filter(Boolean);
    const blocks = await lbatch(c, addrs.map((a) => ({ to: c.factory, data: cdata(SEL.launchedAtBlock, ["address"], [a]) })));
    const logs = await lrpcBatch(c, addrs.map((a, i) => ["eth_getLogs", [{ address: c.factory, topics: [TOPIC_LAUNCHED, "0x" + encAddr(a)], fromBlock: hex(BigInt(blocks[i] || 0)), toBlock: hex(BigInt(blocks[i] || 0)) }]]));
    const rows = addrs.map((a, i) => {
      const l = (logs[i] || [])[0]; if (!l) return null;
      let meta = {}; try { meta = JSON.parse(decString(l.data, 3)); } catch {}
      return { token: a, creator: "0x" + l.topics[2].slice(26), name: decString(l.data, 0), symbol: decString(l.data, 1), meta, time: Number(decUint(l.data, 4)), chainId: c.chainId };
    }).filter(Boolean);
    await verifyLaunched(c, rows);
    if (seq !== LN.recentSeq) return;
    recentCache.set(key, { t: Date.now(), rows }); renderRecent(rows);
  } catch (e) { if (seq === LN.recentSeq) box.innerHTML = `<p class="muted pad">Couldn't load recent launches: ${esc(e.message)}</p>`; }
}
async function lrpcBatch(c, calls) { // generic JSON-RPC batch → results (null on error)
  if (!calls.length) return [];
  try {
    const r = await fetch(c.rpc, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(calls.map(([method, params], id) => ({ jsonrpc: "2.0", id, method, params }))) });
    const j = await r.json(); if (!Array.isArray(j)) throw 0;
    const out = Array(calls.length).fill(null); j.forEach((x) => { if (x && !x.error) out[x.id] = x.result; }); return out;
  } catch { return Promise.all(calls.map(([m, p]) => rpc(c.rpc, m, p).catch(() => null))); }
}
async function verifyLaunched(c, rows) { // on-chain safety badges: renounced, trading open, LP burned
  const r1 = await lbatch(c, rows.flatMap((r) => [{ to: r.token, data: "0x" + SEL.owner }, { to: r.token, data: "0x" + SEL.pair }]));
  rows.forEach((r, i) => { r.renounced = r1[i * 2] != null && /^0x0*$/.test(r1[i * 2]); r.pair = r1[i * 2 + 1] ? decAddr(r1[i * 2 + 1]) : null; if (r.pair && /^0x0+$/.test(r.pair)) r.pair = null; });
  const withPair = rows.filter((r) => r.pair);
  const r2 = await lbatch(c, withPair.flatMap((r) => [{ to: r.pair, data: "0x" + SEL.totalSupply }, { to: r.pair, data: cdata(SEL.balanceOf, ["address"], [DEAD]) }]));
  withPair.forEach((r, i) => { const ts = r2[i * 2] ? BigInt(r2[i * 2]) : 0n, dead = r2[i * 2 + 1] ? BigInt(r2[i * 2 + 1]) : 0n; r.lpBurned = ts > 0n && dead * 100n >= ts * 95n; });
}
function renderRecent(rows, empty = "No coins launched here yet. Be the first!") {
  rows.forEach((r) => { if (r.meta?.i) LAUNCH_LOGOS[r.chainId + ":" + r.token.toLowerCase()] = r.meta.i; });
  $("lnRecent").innerHTML = rows.length ? rows.map((r) => {
    const c = lchain(r.chainId) || {}, ch = S.chainById.get(r.chainId) || { id: r.chainId, name: c.name };
    const links = [r.meta?.w && ["Web", /^https?:/.test(r.meta.w) ? r.meta.w : "https://" + r.meta.w], r.meta?.x && ["X", "https://x.com/" + r.meta.x.replace(/^@|https?:\/\/(x|twitter)\.com\//g, "")], r.meta?.t && ["TG", /^https?:/.test(r.meta.t) ? r.meta.t : "https://" + r.meta.t.replace(/^@/, "t.me/")], r.meta?.c && ["Discord", /^https?:/.test(r.meta.c) ? r.meta.c : "https://" + r.meta.c]].filter(Boolean);
    const badges = [r.lpBurned && "LP burned", r.renounced && "Renounced", r.pair !== undefined && "No tax"].filter(Boolean);
    return `<div class="ln-rc">
      <div class="ln-rc-top"><span class="ico-wrap">${tokImg({ address: r.token, symbol: r.symbol }, r.chainId)}${chainImg(ch, "sub")}</span>
        <div><b>${esc(r.name)}</b><small>$${esc(r.symbol)} · ${age(r.time * 1000)} ago</small></div></div>
      ${r.meta?.d ? `<p class="ln-rc-desc">${esc(r.meta.d)}</p>` : ""}
      <div class="ln-badges">${badges.map((b) => `<em><svg><use href="#i-check"/></svg>${b}</em>`).join("")}</div>
      <div class="ln-rc-foot"><span class="ln-links">${links.map(([t, u]) => `<a href="${esc(u)}" target="_blank" rel="noopener nofollow">${t}</a>`).join("")}<a href="${esc(c.explorer)}/token/${esc(r.token)}" target="_blank" rel="noopener">Explorer</a></span>
        ${r.job && !r.job.finished ? `<button class="btn-sm ghost" data-lnresume="${esc(r.job.id)}">Resume</button>` : `<button class="btn-sm" data-lntrade="${r.chainId}|${esc(r.token)}|${esc(r.symbol)}|${esc(r.name)}">Trade</button>`}</div>
    </div>`;
  }).join("") : `<p class="muted pad">${esc(empty)}</p>`;
}
async function tradeLaunched(chainId, address, symbol, name) {
  chainId = Number(chainId);
  let token = { chainId, address, symbol, name, decimals: 18, priceUSD: "0", logoURI: LAUNCH_LOGOS[chainId + ":" + address.toLowerCase()] || "" };
  try { const t = await api("/token", { chain: chainId, token: address }); token = { ...t, logoURI: t.logoURI || token.logoURI }; } catch {}
  S.to = { chainId, token };
  if (S.chainById.has(chainId)) S.from = { chainId, token: await defaultTokens(chainId, false) };
  setTab("swap"); refreshLegBalances(); scheduleQuote(50);
}

/* --- admin: deploy factory / sync fee --- */
async function adminDeploy() {
  const c = lchain(), out = $("lnAdmOut");
  if (!S.evm) return openWalletModal();
  const treasury = $("lnAdmTreasury").value.trim();
  if (!/^0x[0-9a-fA-F]{40}$/.test(treasury)) return toast("Enter a valid treasury address", true);
  try {
    await ensureLaunchChain(c);
    const price = await natPrice(c.chainId);
    if (!price) return toast(`Couldn't get the ${c.native} price to set the fee`, true);
    const floor = parseUnits(((LC.FEE_USD || 1) * (LC.FEE_FLOOR_SHARE ?? 0.8) / price).toFixed(18), 18);
    out.textContent = "Confirm the deployment in your wallet…";
    const h = await sendTx({ data: window.NXT_LAUNCH_FACTORY_BYTECODE + encodeArgs(["address", "uint256"], [treasury, floor]) });
    out.textContent = "Deploying… waiting for confirmation";
    const rc = await waitReceipt(h);
    out.innerHTML = `Factory deployed on ${esc(c.name)}: <code>${esc(rc.contractAddress)}</code><br>Paste it as <code>factory</code> for chainId ${c.chainId} in config.js, then redeploy the site.`;
  } catch (e) { out.textContent = "Failed: " + (e.message || e); }
}
async function adminSetFee() {
  const c = lchain(); if (!S.evm) return openWalletModal(); if (!hasFactory(c)) return toast("Deploy the factory first", true);
  try {
    await ensureLaunchChain(c);
    const price = await natPrice(c.chainId); if (!price) return toast("Price unavailable", true);
    const floor = parseUnits(((LC.FEE_USD || 1) * (LC.FEE_FLOOR_SHARE ?? 0.8) / price).toFixed(18), 18);
    const h = await sendTx({ to: c.factory, data: cdata(SEL.setLaunchFee, ["uint256"], [floor]) }); await waitReceipt(h);
    $("lnAdmOut").textContent = `On-chain minimum fee set to ${fmtNat(floor, c.native)}.`; selectLaunchChain(c.chainId);
  } catch (e) { $("lnAdmOut").textContent = "Failed: " + (e.message || e); }
}
function bindLaunch() {
  $("lnChains").addEventListener("click", (e) => { const b = e.target.closest("[data-lchain]"); if (b) selectLaunchChain(b.dataset.lchain); });
  ["lnName", "lnSym", "lnDesc", "lnSupply", "lnLiq", "lnBuy", "lnAlloc", "lnLogoUrl", "lnWeb", "lnX", "lnTg", "lnDc"].forEach((id) => $(id).addEventListener("input", renderLnPreview));
  ["lnBurn", "lnRenounce"].forEach((id) => $(id).addEventListener("change", renderLnPreview));
  $("lnSupply").addEventListener("blur", () => { const n = lnNum("lnSupply"); if (n) $("lnSupply").value = Math.floor(n).toLocaleString("en-US"); });
  $("lnSym").addEventListener("input", (e) => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9$._-]/g, ""); });
  $("lnLogoFile").addEventListener("change", (e) => lnLogoFromFile(e.target.files[0]));
  const drop = $("lnLogoDrop");
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("over"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("over"));
  drop.addEventListener("drop", (e) => { e.preventDefault(); drop.classList.remove("over"); lnLogoFromFile(e.dataTransfer.files[0]); });
  $("lnLogoUrlBtn").addEventListener("click", (e) => { e.preventDefault(); $("lnLogoUrlWrap").classList.toggle("hidden"); });
  $("lnLogoUrl").addEventListener("input", () => { LN.logo = ""; const u = $("lnLogoUrl").value.trim(); $("lnLogoImg").src = u; $("lnLogoImg").classList.toggle("hidden", !u); $("lnLogoPh").classList.toggle("hidden", !!u); });
  $("lnSnipe").addEventListener("click", (e) => { const b = e.target.closest("[data-v]"); if (!b) return; LN.snipe = +b.dataset.v; $("lnSnipe").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b)); $("lnMaxW").classList.toggle("dim", !LN.snipe); renderLnPreview(); });
  $("lnMaxW").addEventListener("click", (e) => { const b = e.target.closest("[data-v]"); if (!b) return; LN.maxW = +b.dataset.v; $("lnMaxW").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b)); renderLnPreview(); });
  $("lnGo").addEventListener("click", () => { const m = $("lnGo").dataset.mode; if (m === "connect") openWalletModal(); else if (m === "buy") buyNxt(); else if (m === "show") $("lnModal").classList.remove("hidden"); else if (m === "go") startLaunch(); });
  $("lnMBtns").addEventListener("click", (e) => {
    const a = e.target.closest("[data-lnact]")?.dataset.lnact; const job = LN.running || loadJobs()[0];
    if (!a || !job) return;
    if (a === "retry") runJob(job);
    if (a === "trade") { closeModals(); LN.running = null; tradeLaunched(job.chainId, job.token, job.p.symbol, job.p.name); }
    if (a === "copy") navigator.clipboard?.writeText(job.token).then(() => toast("Address copied"));
  });
  $("lnRecentScope").addEventListener("click", (e) => { const b = e.target.closest("[data-v]"); if (!b) return; LN.scope = b.dataset.v; $("lnRecentScope").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b)); loadLaunchRecent(); });
  $("lnRecent").addEventListener("click", (e) => {
    const t = e.target.closest("[data-lntrade]"); if (t) { const [cid, a, sym, nm] = t.dataset.lntrade.split("|"); return tradeLaunched(cid, a, sym, nm); }
    const r = e.target.closest("[data-lnresume]"); if (r) { const job = loadJobs().find((j) => j.id === r.dataset.lnresume); if (job) { if (!S.evm) return openWalletModal(); runJob(job); } }
  });
  $("lnAdmDeploy").addEventListener("click", adminDeploy);
  $("lnAdmSetFee").addEventListener("click", adminSetFee);
  window.addEventListener("hashchange", () => { if (S.tab === "launch") openLaunch(); });
}

/* ---------- events ---------- */
function bind() {
  bindLaunch();
  $("exTabs").addEventListener("click", (e) => { const b = e.target.closest("[data-ex]"); if (!b) return; EX.tab = b.dataset.ex; if (EX.tab === "gainers") $("exSort").value = "default"; loadExplore(); });
  $("exChains").addEventListener("click", (e) => { const b = e.target.closest("[data-net]"); if (!b) return; EX.net = b.dataset.net; loadExplore(); });
  $("exTf").addEventListener("click", (e) => { const b = e.target.closest("[data-tf]"); if (!b) return; EX.tf = b.dataset.tf; renderExplore(); });
  ["exLiq", "exVol", "exAge", "exSort"].forEach((id) => $(id).addEventListener("change", renderExplore));
  let exT; $("exSearch").addEventListener("input", () => { clearTimeout(exT); exT = setTimeout(renderExplore, 150); });
  $("exMore").addEventListener("click", () => loadExplore(true));
  $("exList").addEventListener("click", (e) => { const t = e.target.closest("[data-trade]"); if (t) return tradeCoin(t.dataset.trade); if (e.target.closest("[data-exretry]")) { EX.loadedKey = ""; loadExplore(); } });
  document.querySelectorAll("[data-nav]").forEach((n) => n.addEventListener("click", (e) => { const b = e.target.closest("button[data-tab]"); if (b) setTab(b.dataset.tab); }));
  $("searchBtn").addEventListener("click", () => openTokModal("to"));
  $("actRecv").addEventListener("click", openReceive);
  $("recvList").addEventListener("click", (e) => { const b = e.target.closest("[data-copy]"); if (b) navigator.clipboard?.writeText(b.dataset.copy).then(() => toast("Address copied")); });
  document.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", () => setTab(b.dataset.go)));
  ["connectBtn", "connectBtn2"].forEach((id) => $(id).addEventListener("click", openWalletModal));
  $("fromTokBtn").addEventListener("click", () => openTokModal("from"));
  $("toTokBtn").addEventListener("click", () => openTokModal("to"));
  $("fromAmount").addEventListener("input", (e) => {
    e.target.value = e.target.value.replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1");
    renderQuote(); renderAction(); scheduleQuote();
  });
  $("maxBtn").addEventListener("click", () => {
    if (S.fromBalRaw == null) return;
    let v = S.fromBalRaw;
    if (isNative(S.from.token)) { const keep = chainType(S.from.chainId) === "SVM" ? 10_000_000n : parseUnits("0.002", 18) * (S.from.chainId === 1 ? 5n : 1n); v = v > keep ? v - keep : 0n; }
    $("fromAmount").value = formatUnits(v, S.from.token.decimals); renderQuote(); scheduleQuote(50);
  });
  $("flipBtn").addEventListener("click", () => { [S.from, S.to] = [S.to, S.from]; renderLegs(); refreshLegBalances(); scheduleQuote(50); });
  $("refreshBtn").addEventListener("click", () => getQuote());
  $("settingsBtn").addEventListener("click", () => $("slipBox").classList.toggle("hidden"));
  $("slipBox").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-slip]"); if (!b) return;
    S.slippage = Number(b.dataset.slip); $("slipCustom").value = "";
    document.querySelectorAll("[data-slip]").forEach((x) => x.classList.toggle("on", x === b)); scheduleQuote(50);
  });
  $("slipCustom").addEventListener("input", (e) => {
    const v = Number(e.target.value); if (v > 0 && v <= 50) { S.slippage = v / 100; document.querySelectorAll("[data-slip]").forEach((x) => x.classList.remove("on")); scheduleQuote(); }
  });
  $("actionBtn").addEventListener("click", (e) => e.currentTarget.dataset.mode === "buy" ? buyNxt() : (!addrFor(S.from.chainId) || !addrFor(S.to.chainId)) ? openWalletModal() : execute());
  $("gateBox").addEventListener("click", (e) => { const b = e.target.closest("[data-gate]"); if (!b) return; b.dataset.gate === "buy" ? buyNxt() : checkAccess(); });
  document.querySelectorAll(".modal").forEach((m) => m.addEventListener("click", (e) => { if (e.target === m || e.target.closest("[data-close]")) closeModals(); }));
  document.addEventListener("keydown", (e) => e.key === "Escape" && closeModals());
  $("chainGrid").addEventListener("click", (e) => { const b = e.target.closest("button[data-chain]"); if (!b) return; S.pickChain = Number(b.dataset.chain); renderChainGrid(); renderTokList(); });
  let sT; $("tokSearch").addEventListener("input", () => { clearTimeout(sT); sT = setTimeout(renderTokList, 200); });
  $("tokList").addEventListener("click", (e) => {
    const b = e.target.closest(".tok-row"); if (!b) return;
    const i = b.dataset.i; const list = S.tokens.get(Number(S.pickChain)) || [];
    pickToken(i.startsWith("x") ? $("tokList")._extra[Number(i.slice(1))] : list[Number(i)]);
  });
  $("walEvm").addEventListener("click", (e) => { const b = e.target.closest("[data-evm]"); if (b) connectEvm(b.dataset.evm); });
  $("walSol").addEventListener("click", (e) => { const b = e.target.closest("[data-sol]"); if (b) connectSol(b.dataset.sol); });
  $("wAccounts").addEventListener("click", (e) => {
    const b = e.target.closest("[data-disc]"); if (!b) return;
    if (b.dataset.disc === "sol") { S.sol?.provider.disconnect?.(); S.sol = null; } else S.evm = null;
    onWalletChange();
  });
  $("refreshPort").addEventListener("click", loadPortfolio);
  $("clearAct").addEventListener("click", () => { saveAct([]); renderActivity(); });
  $("netChip").addEventListener("click", () => openTokModal("from"));
}

/* ---------- boot ---------- */
async function boot() {
  bind(); discoverEvm(); setTab("home");
  try {
    await loadChains();
    if (!S.chainById.has(S.from.chainId)) S.from.chainId = S.chains[0].id;
    if (!S.chainById.has(S.to.chainId)) S.to.chainId = S.from.chainId;
    [S.from.token, S.to.token] = await Promise.all([defaultTokens(S.from.chainId, false), defaultTokens(S.to.chainId, true)]);
  } catch (e) { toast("Couldn't reach the routing API: " + e.message, true, 10000); }
  setTab("home"); renderConnect(); renderActivity(); resumeTracking();
  // silently restore previously-trusted Phantom Solana session
  try { const ph = window.phantom?.solana; if (ph?.isPhantom) { const r = await ph.connect({ onlyIfTrusted: true }); S.sol = { key: "phantom", name: "Phantom", icon: solIcon("phantom", "https://phantom.com/favicon.ico"), provider: ph, address: r.publicKey.toString() }; onWalletChange(); } } catch {}
}
boot();
})();
