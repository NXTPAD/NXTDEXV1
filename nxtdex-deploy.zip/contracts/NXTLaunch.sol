// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/*
 * NXT Launch: token factory for NXT DEX
 *
 * NXTLaunchToken: plain ERC-20 (18 decimals, fixed supply, no mint, no tax) with:
 *   - Trading locked until the creator opens it, so bots can't buy the instant the pool appears.
 *     (Only the creator can move tokens before that: adding liquidity, the optional early buy.)
 *   - Anti-snipe window: for the first N blocks after opening, a wallet buying from the pool
 *     can't end up holding more than maxWalletBps of supply.
 *   - The creator's only powers: openTrading() once, and renounceOwnership(). No blacklist,
 *     no pause, no fee switch, no mint.
 *
 * NXTLaunchFactory: deploys tokens, collects the launch fee to the treasury, keeps a registry
 * and emits TokenLaunched (metadata such as the logo and links lives only in the event log).
 */

contract NXTLaunchToken {
    string public name;
    string public symbol;
    uint8 public constant decimals = 18;
    uint256 public immutable totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    address public owner;
    address public immutable creator;
    address public immutable factory;
    address public pair;
    bool public tradingOpen;
    uint256 public launchBlock;
    uint16 public immutable antiSnipeBlocks;
    uint16 public immutable maxWalletBps;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event TradingOpened(address indexed pair, uint256 blockNumber);

    error TradingNotOpen();
    error AntiSnipeLimit();
    error NotOwner();

    constructor(
        string memory _name,
        string memory _symbol,
        uint256 _supplyWholeTokens,
        address _creator,
        uint16 _antiSnipeBlocks,
        uint16 _maxWalletBps
    ) {
        require(_supplyWholeTokens > 0 && _supplyWholeTokens <= 1e15, "supply");
        require(_antiSnipeBlocks <= 100, "blocks");
        require(_maxWalletBps > 0 && _maxWalletBps <= 10000, "maxWallet");
        name = _name;
        symbol = _symbol;
        creator = _creator;
        owner = _creator;
        factory = msg.sender;
        antiSnipeBlocks = _antiSnipeBlocks;
        maxWalletBps = _maxWalletBps;
        uint256 supply = _supplyWholeTokens * 1e18;
        totalSupply = supply;
        balanceOf[_creator] = supply;
        emit OwnershipTransferred(address(0), _creator);
        emit Transfer(address(0), _creator, supply);
    }

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    function openTrading(address _pair) external onlyOwner {
        require(!tradingOpen, "open");
        require(_pair != address(0), "pair");
        pair = _pair;
        tradingOpen = true;
        launchBlock = block.number;
        emit TradingOpened(_pair, block.number);
    }

    function renounceOwnership() external onlyOwner {
        require(tradingOpen, "open trading first");
        emit OwnershipTransferred(owner, address(0));
        owner = address(0);
    }

    function transfer(address to, uint256 value) external returns (bool) {
        _transfer(msg.sender, to, value);
        return true;
    }

    function approve(address spender, uint256 value) external returns (bool) {
        allowance[msg.sender][spender] = value;
        emit Approval(msg.sender, spender, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) external returns (bool) {
        uint256 allowed = allowance[from][msg.sender];
        if (allowed != type(uint256).max) {
            require(allowed >= value, "allowance");
            allowance[from][msg.sender] = allowed - value;
        }
        _transfer(from, to, value);
        return true;
    }

    function _transfer(address from, address to, uint256 value) internal {
        require(to != address(0), "zero");
        if (!tradingOpen) {
            if (from != creator && to != creator) revert TradingNotOpen();
        } else if (from == pair && to != creator && block.number < launchBlock + antiSnipeBlocks) {
            if (balanceOf[to] + value > (totalSupply * maxWalletBps) / 10000) revert AntiSnipeLimit();
        }
        uint256 bal = balanceOf[from];
        require(bal >= value, "balance");
        unchecked {
            balanceOf[from] = bal - value;
        }
        balanceOf[to] += value;
        emit Transfer(from, to, value);
    }
}

contract NXTLaunchFactory {
    address public owner;
    address payable public treasury;
    uint256 public launchFee; // in native wei
    address[] public allTokens;
    // Block each token was launched in, so front-ends can fetch its TokenLaunched event
    // (metadata: logo, links) with a single-block log query that works on any public RPC.
    mapping(address => uint256) public launchedAtBlock;

    event TokenLaunched(
        address indexed token,
        address indexed creator,
        string name,
        string symbol,
        uint256 supply,
        string metadata,
        uint256 timestamp
    );
    event FeeUpdated(uint256 fee);
    event TreasuryUpdated(address treasury);

    constructor(address payable _treasury, uint256 _launchFee) {
        require(_treasury != address(0), "treasury");
        owner = msg.sender;
        treasury = _treasury;
        launchFee = _launchFee;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "owner");
        _;
    }

    function createToken(
        string calldata _name,
        string calldata _symbol,
        uint256 _supplyWholeTokens,
        uint16 _antiSnipeBlocks,
        uint16 _maxWalletBps,
        string calldata _metadata
    ) external payable returns (address token) {
        require(msg.value >= launchFee, "fee");
        require(bytes(_name).length > 0 && bytes(_name).length <= 40, "name");
        require(bytes(_symbol).length > 0 && bytes(_symbol).length <= 12, "symbol");
        require(bytes(_metadata).length <= 12000, "metadata");
        token = address(
            new NXTLaunchToken(_name, _symbol, _supplyWholeTokens, msg.sender, _antiSnipeBlocks, _maxWalletBps)
        );
        allTokens.push(token);
        launchedAtBlock[token] = block.number;
        if (msg.value > 0) {
            (bool ok, ) = treasury.call{value: msg.value}("");
            require(ok, "treasury");
        }
        emit TokenLaunched(token, msg.sender, _name, _symbol, _supplyWholeTokens, _metadata, block.timestamp);
    }

    function allTokensLength() external view returns (uint256) {
        return allTokens.length;
    }

    function setLaunchFee(uint256 _fee) external onlyOwner {
        launchFee = _fee;
        emit FeeUpdated(_fee);
    }

    function setTreasury(address payable _treasury) external onlyOwner {
        require(_treasury != address(0), "treasury");
        treasury = _treasury;
        emit TreasuryUpdated(_treasury);
    }

    function transferOwnership(address _owner) external onlyOwner {
        require(_owner != address(0), "owner");
        owner = _owner;
    }
}
