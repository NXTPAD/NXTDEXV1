/* ============================================================
   NXT DEX — the only file you need to edit.
   ============================================================

   ACCESS: HOLD NXT
   ----------------
   Swapping and bridging are free, but only for wallets that hold
   some NXT (any amount above zero). Anyone can still buy NXT
   on the site, so new users have a way in.

   Paste your NXT token contract(s) below. If NXT exists on more
   than one chain, list each one. Holding it on ANY of them unlocks access.
*/
window.NXT_CONFIG = {
  // --- NXT holder gate ------------------------------------------------
  NXT_TOKENS: [
    // EVM example (Base):
    { chainId: 8453, address: "PASTE_NXT_TOKEN_CONTRACT_ON_BASE", decimals: 18 },
    // Solana example (the mint address):
    // { chainId: 1151111081099710, address: "PASTE_NXT_MINT_ADDRESS", decimals: 9 },
  ],
  NXT_SYMBOL: "NXT",
  NXT_LOGO: "assets/logos/nxt.svg", // swap for your NXT coin logo (e.g. "logo.png")
  NXT_MIN_BALANCE: "0",            // must hold MORE than this (in whole tokens). "0" = any amount.

  // --- Routing (LI.FI) ------------------------------------------------
  INTEGRATOR: "nxtdex",            // identifies your site to LI.FI (no fee is charged)
  LIFI_API_KEY: "",                // optional, from portal.li.fi (higher rate limits)

  // --- Explore tab market data (GeckoTerminal) ------------------------
  // Works with no key (about 10 requests/min per visitor, cached).
  // If you buy a CoinGecko API plan, set these for higher limits:
  //   GECKO_BASE: "https://pro-api.coingecko.com/api/v3/onchain", GECKO_API_KEY: "your-key"
  GECKO_BASE: "https://api.geckoterminal.com/api/v2",
  GECKO_API_KEY: "",

  // --- Launchpad (Launch tab) ------------------------------------------
  // One-time setup per chain: open your site with #admin at the end of the URL
  // (e.g. https://nxtdex.pages.dev/#admin), go to Launch, connect the wallet
  // you want as owner, and press "Deploy factory". Paste the address it gives you
  // into "factory" for that chain below. Chains without a factory show "Setup needed".
  LAUNCH: {
    // Receives the $1 launch fees. Used by the #admin "Deploy factory" button on every EVM chain
    // (Base, Ethereum, Arbitrum, BNB Chain, Polygon, Avalanche, Optimism, Robinhood Chain).
    TREASURY: "0x5ef1aA7D7e1Af09D058034d842EdA44D2B5b538c",
    // Treasuries for chains that aren't launchable yet (kept here for when they're added):
    TREASURIES_OTHER: {
      solana: "4RoSq9JJN6jhZ7HAYjQx7reTPqS8LiyG7RhbXuJFkrZc",
      sui: "0xb5d24dcd4d25bf7d0eab298cccf8d513ce3a100f915090dbc028b584cdc44154",
      bitcoin: "bc1q3j93pcxlvj4xw958pr0kg9jfkdgw5vm3ywrlcm",
      arc: "0x5ef1aA7D7e1Af09D058034d842EdA44D2B5b538c",
      hyperevm: "0x5ef1aA7D7e1Af09D058034d842EdA44D2B5b538c",
    },
    FEE_USD: 1,                               // launch fee in USD, charged in the chain's native coin at the live price
    // On-chain safety floor: the factory rejects launches paying less than this share of FEE_USD
    // (at the price when you last pressed "Update fee" in #admin), in case the live price is unavailable.
    FEE_FLOOR_SHARE: 0.8,
    // A chain only appears to users when it has BOTH a deployed factory and a working RPC.
    // Routers are each chain's official Uniswap V2 Router02 (from Uniswap's deployment docs).
    // RPCs are PublicNode's free endpoints (CORS, batching and log queries supported).
    // priceChain: where the native coin's USD price comes from, for the $1 fee.
    CHAINS: [
      { chainId: 8453,  name: "Base",      native: "ETH",  priceChain: 1,     factory: "", router: "0x4752ba5dbc23f44d87826276bf6fd6b1c372ad24", rpc: "https://base-rpc.publicnode.com",               explorer: "https://basescan.org" },
      { chainId: 1,     name: "Ethereum",  native: "ETH",  priceChain: 1,     factory: "", router: "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D", rpc: "https://ethereum-rpc.publicnode.com",           explorer: "https://etherscan.io" },
      { chainId: 42161, name: "Arbitrum",  native: "ETH",  priceChain: 1,     factory: "", router: "0x4752ba5dbc23f44d87826276bf6fd6b1c372ad24", rpc: "https://arbitrum-one-rpc.publicnode.com",       explorer: "https://arbiscan.io" },
      { chainId: 56,    name: "BNB Chain", native: "BNB",  priceChain: 56,    factory: "", router: "0x4752ba5DBc23f44D87826276BF6Fd6b1C372aD24", rpc: "https://bsc-rpc.publicnode.com",                explorer: "https://bscscan.com" },
      { chainId: 137,   name: "Polygon",   native: "POL",  priceChain: 137,   factory: "", router: "0xedf6066a2b290C185783862C7F4776A2C8077AD1", rpc: "https://polygon-bor-rpc.publicnode.com",        explorer: "https://polygonscan.com" },
      { chainId: 43114, name: "Avalanche", native: "AVAX", priceChain: 43114, factory: "", router: "0x4752ba5dbc23f44d87826276bf6fd6b1c372ad24", rpc: "https://avalanche-c-chain-rpc.publicnode.com",  explorer: "https://snowtrace.io" },
      { chainId: 10,    name: "Optimism",  native: "ETH",  priceChain: 1,     factory: "", router: "0x4A7b5Da61326A6379179b40d00F57E5bbDC962c2", rpc: "https://optimism-rpc.publicnode.com",           explorer: "https://optimistic.etherscan.io" },
      // Robinhood Chain stays hidden until you add a reliable RPC. Its official docs only list
      // Alchemy: create a free key at alchemy.com and use https://robinhood-mainnet.g.alchemy.com/v2/YOUR_KEY
      { chainId: 4663,  name: "Robinhood Chain", native: "ETH", priceChain: 1, factory: "", router: "0x89e5db8b5aa49aa85ac63f691524311aeb649eba", rpc: "", explorer: "https://robinhoodchain.blockscout.com" },
    ],
  },

  // --- Defaults ------------------------------------------------------
  DEFAULT_SLIPPAGE: 0.005,         // 0.5%
  DEFAULT_FROM_CHAIN: 8453,        // Base
  DEFAULT_TO_CHAIN: 8453,
  // Solana RPC for balance reads. The public one rate-limits hard;
  // a free Helius / QuickNode / Alchemy URL works much better.
  SOLANA_RPC: "https://api.mainnet-beta.solana.com",

  // Chains shown in the wallet token list (IDs). Solana is added automatically.
  PORTFOLIO_CHAINS: [1, 8453, 42161, 10, 137, 56, 43114],
};
